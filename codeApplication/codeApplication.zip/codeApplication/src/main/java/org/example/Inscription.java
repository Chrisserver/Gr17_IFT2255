package org.example;

import com.google.gson.Gson;


import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.UUID;

public class Inscription {
    public static void inscrireResident(String courriel, String motDePasse, String nom, String dateNaissance, String telephone, String adresse, String preferencesHoraires, ArrayList<Resident> residents) {

        // Extraire le code postal
        String codePostal = adresse.split(" ")[0];
        String quartier = ResidentService.getQuartierParCodePostal(codePostal);

        Resident resident = new Resident(
                nom,
                courriel,
                motDePasse,
                dateNaissance,
                telephone,
                adresse,
                quartier,
                preferencesHoraires,
                UUID.randomUUID().toString(),
                new ArrayList<Notification>()
        );

        try {
            URL url = new URL("http://localhost:7000/residents");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            Gson gson = new Gson();
            String jsonResident = gson.toJson(resident);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonResident.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == 201) {
                System.out.println("Resident ajouté avec succès !");
            } else {
                System.out.println("Erreur lors de l'ajout du resident. Code : " + responseCode);
            }

            MaVille.residents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json", Resident.class);
            MaVille.residentsMap = ResidentService.getInstance().chargerResidentsEnMap();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void inscrireIntervenant(String nom, String courriel, String motDePasse, String type, String identifiantVille, ArrayList<Intervenant> intervenants) {
        Intervenant intervenant = new Intervenant(
                nom,
                courriel,
                motDePasse,
                type,
                identifiantVille,
                new ArrayList<String>()
        );

        try {
            URL url = new URL("http://localhost:7000/intervenants");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            Gson gson = new Gson();
            String jsonIntervenant = gson.toJson(intervenant);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonIntervenant.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == 201) {
                System.out.println("Intervenant ajouté avec succès !");
            } else {
                System.out.println("Erreur lors de l'ajout de l'intervenant. Code : " + responseCode);
            }

            MaVille.residents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json", Resident.class);
            MaVille.residentsMap = ResidentService.getInstance().chargerResidentsEnMap();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static boolean validerCourriel(String courriel) {
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return courriel.matches(regex);
    }

    private static boolean validerMotDePasse(String motDePasse) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d]{8,}$";
        return motDePasse.matches(regex);
    }
}