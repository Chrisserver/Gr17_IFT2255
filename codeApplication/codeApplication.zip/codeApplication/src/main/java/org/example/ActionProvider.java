package org.example;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.UUID;

import com.google.gson.Gson;

public class ActionProvider {   

    public static String soumettreProjet(String idIntervenant, String titre, String description, String typeTravaux, ArrayList<String> quartiersAffectes, ArrayList<String> ruesAffectees, String dateDebut, String dateFin, String horaireTravaux) throws IOException {
        String idForm = UUID.randomUUID().toString();
            // Création de l'objet ProjetTravaux
            ProjetTravaux projet = new ProjetTravaux(
                idForm, // Id de l'intervenant associé
                titre,
                description,
                typeTravaux,
                quartiersAffectes,
                ruesAffectees,
                dateDebut,
                dateFin,
                horaireTravaux,
                "Prévu"
        );

        try {
            URL url = new URL("http://localhost:7000/projets");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            Gson gson = new Gson();
            String jsonProjet = gson.toJson(projet);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonProjet.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == 201) {
                String message = "Un nouveau projet a été soumis dans votre quartier : " + projet.getTitre();
                ResidentService.getInstance().notifierResidentsParQuartier(projet.getQuartiersAffectes(), message);
                System.out.println("Projet soumis et notifications envoyées avec succès !");
            } else {
                System.out.println("Erreur lors de l'ajout du projet. Code : " + responseCode);
            }

        } catch (IOException e) {
            System.out.println("Une erreur s'est produite lors de la soumission du projet : " + e.getMessage());
        }

        // Mise à jour des projets dans MaVille
        MaVille.projets = ProjetEntravesService.getInstance().chargerProjetsDepuisApi();
        return idForm;
    }

    public static String soumettreRequete(String residentID, String titre, String description, String type, String dateDebut) throws IOException {
        String idForm = UUID.randomUUID().toString();

        String jsonRequete = String.format(
                "{\"ID\":\"%s\", \"titreTravail\":\"%s\", \"descriptionDetaillee\":\"%s\", \"typeTravaux\":\"%s\", \"dateDebutEsperee\":\"%s\", \"residentID\":\"%s\"}",
                idForm, titre, description, type, dateDebut, residentID
        );

        try {
            URL url = new URL("http://localhost:7000/requetes");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonRequete.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
        } catch (Exception e) {
            e.printStackTrace();
        }
        MaVille.requetes = (ArrayList<RequeteTravail>) RequeteAPI.readFromFile("requetes.json",RequeteTravail.class);
        return idForm;
    }

    public static void inscrireResident(String courriel, String motDePasse, String nom, String dateNaissance, String telephone, String adresse, String preferencesHoraires, ArrayList<Resident> residents) {

        // Extraire le code postal
        String codePostal = adresse.split(" ")[0];
        String quartier = ResidentService.getQuartierParCodePostal(codePostal);

        Resident resident = new Resident(
                nom,
                courriel,
                motDePasse,
                dateNaissance,
                telephone,
                adresse,
                quartier,
                preferencesHoraires,
                UUID.randomUUID().toString(),
                new ArrayList<>()
        );

        try {
            URL url = new URL("http://localhost:7000/residents");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            Gson gson = new Gson();
            String jsonResident = gson.toJson(resident);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonResident.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == 201) {
                System.out.println("Resident ajouté avec succès !");
            } else {
                System.out.println("Erreur lors de l'ajout du resident. Code : " + responseCode);
            }

            MaVille.residents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json", Resident.class);
            MaVille.residentsMap = ResidentService.getInstance().chargerResidentsEnMap();

        } catch (IOException e) {}
    }

    public static void inscrireIntervenant(String nom, String courriel, String motDePasse, String type, String identifiantVille, ArrayList<Intervenant> intervenants) {
        Intervenant intervenant = new Intervenant(
                nom,
                courriel,
                motDePasse,
                type,
                identifiantVille,
                new ArrayList<>()
        );

        try {
            URL url = new URL("http://localhost:7000/intervenants");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            Gson gson = new Gson();
            String jsonIntervenant = gson.toJson(intervenant);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonIntervenant.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == 201) {
                System.out.println("Intervenant ajouté avec succès !");
            } else {
                System.out.println("Erreur lors de l'ajout de l'intervenant. Code : " + responseCode);
            }

            MaVille.residents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json", Resident.class);
            MaVille.residentsMap = ResidentService.getInstance().chargerResidentsEnMap();

        } catch (IOException e) {}
    }

    public static String[] connexion(String emailConnexion, String motDePasse, ArrayList<Resident> residents, ArrayList<Intervenant> intervenants) throws IOException {
        for (Resident resident : residents) {
            if (resident.getCourriel().equalsIgnoreCase(emailConnexion) && resident.getMotDePasse().equals(motDePasse)) {
                System.out.println("Connexion réussie en tant que Resident!");
                return new String[]{"Resident", resident.getID()};
            }
        }

        for (Intervenant intervenant : intervenants) {
            if (intervenant.getCourriel().equalsIgnoreCase(emailConnexion) && intervenant.getMotDePasse().equals(motDePasse)) {
                System.out.println("Connexion réussie en tant qu'Intervenant!");
                return new String[]{"Intervenant", intervenant.getIdentifiantVille()};
            }
        }

        return new String[]{"None",""};
    }

    public static void rajouterNotification(String idUtilisateur, String titre, String message, String idDocument) {
        String id = UUID.randomUUID().toString();
        Notification notification = new Notification(
                id,
                idUtilisateur,
                titre,
                message,
                idDocument
        );

        try {
            URL url = new URL("http://localhost:7000/Notifications");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            Gson gson = new Gson();
            String jsonNotification = gson.toJson(notification);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonNotification.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == 201) {
                System.out.println("Notification ajouté avec succès !");
            } else {
                System.out.println("Erreur lors de l'ajout de la notification. Code : " + responseCode);
            }

            MaVille.notifications = (ArrayList<Notification>) UtilisateursAPI.readFromFile("src/main/resources/Notifications.json", Notification.class);

        } catch (IOException e) {}
    }

    public static void addCandidature(String requeteID, String candidatID) {
        try {
            ArrayList<RequeteTravail> requetes = MaVille.requetes;
            ArrayList<Intervenant> intervenants = MaVille.intervenants;

            boolean updated = false;

            // Mise à jour de la requête
            for (RequeteTravail requete : requetes) {
                if (requete.getID().equals(requeteID)) {
                    ArrayList<String> candidatures = requete.getCandidatures();
                    if (!candidatures.contains(candidatID)) {
                        candidatures.add(candidatID);
                        requete.setCandidatures(candidatures);
                        updated = true;
                    }
                    break;
                }
            }

            // Mise à jour de l'intervenant
            for (Intervenant intervenant : intervenants) {
                if (intervenant.getIdentifiantVille().equals(candidatID)) {
                    ArrayList<String> requetesCandidate = intervenant.getRequetesCandidate();
                    if (!requetesCandidate.contains(requeteID)) {
                        requetesCandidate.add(requeteID);
                        intervenant.setRequetesCandidate(requetesCandidate);
                        updated = true;
                    }
                    break;
                }
            }

            // Sauvegarde des mises à jour
            if (updated) {
                RequeteAPI.writeToFile("requetes.json", requetes);
                UtilisateursAPI.writeToFile("Intervenants.json", intervenants);

                // Synchroniser MaVille
                MaVille.requetes = (ArrayList<RequeteTravail>) RequeteAPI.readFromFile("src/main/resources/requetes.json",RequeteTravail.class);
                MaVille.intervenants = (ArrayList<Intervenant>) UtilisateursAPI.readFromFile("src/main/resources/Intervenants.json", Intervenant.class);
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la mise à jour des candidatures : " + e.getMessage());
        }
    }
    
    public static void soustraireCandidature(String requeteID, String candidatID) {
        try {
            ArrayList<RequeteTravail> requetes = MaVille.requetes;
            ArrayList<Intervenant> intervenants = MaVille.intervenants;

            boolean updated = false;

            // Suppression de la candidature dans la requête
            for (RequeteTravail requete : requetes) {
                if (requete.getID().equals(requeteID)) {
                    ArrayList<String> candidatures = requete.getCandidatures();
                    if (candidatures.contains(candidatID)) {
                        candidatures.remove(candidatID);
                        requete.setCandidatures(candidatures);
                        updated = true;
                    }
                    break;
                }
            }

            // Suppression de la requête dans l'intervenant
            for (Intervenant intervenant : intervenants) {
                if (intervenant.getIdentifiantVille().equals(candidatID)) {
                    ArrayList<String> requetesCandidate = intervenant.getRequetesCandidate();
                    if (requetesCandidate.contains(requeteID)) {
                        requetesCandidate.remove(requeteID);
                        intervenant.setRequetesCandidate(requetesCandidate);
                        updated = true;
                    }
                    break;
                }
            }

            // Sauvegarde des mises à jour
            if (updated) {
                RequeteAPI.writeToFile("src/main/resources/requetes.json", requetes);
                UtilisateursAPI.writeToFile("src/main/resources/Intervenants.json", intervenants);

                // Synchroniser MaVille
                MaVille.requetes = (ArrayList<RequeteTravail>) RequeteAPI.readFromFile("src/main/resources/requetes.json",RequeteTravail.class);
                MaVille.intervenants = (ArrayList<Intervenant>) UtilisateursAPI.readFromFile("src/main/resources/Intervenants.json", Intervenant.class);
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la suppression des candidatures : " + e.getMessage());
        }
    }

    public static void voirNotifications(Resident resident, Notification notification) {
        ArrayList<Notification> notifications = resident.getNotifications();

        for (Notification notif : notifications) {
            if (notif.getId().equals(notification.getId())) {
                notif.setVue(true);
            }
        }

        for (Resident resident1 : MaVille.residents) {
            if (resident.getID().equals(resident1.getID())) {
                resident1.setNotifications(notifications);
                break;
            }
        }

        //System.out.println((MaVille.residents.get(0).getNotifications()).get(0).getVue());

        // Mise à jour du fichier JSON
        UtilisateursAPI.writeToFile("Residents.json", MaVille.residents);
    };

    public static boolean validerCourriel(String courriel) {
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return courriel.matches(regex);
    }

    public static boolean validerMotDePasse(String motDePasse) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d]{8,}$";
        return motDePasse.matches(regex);
    }

}
