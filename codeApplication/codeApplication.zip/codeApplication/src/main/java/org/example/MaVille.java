package org.example;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public class MaVille {
    private static MaVille instance;

    public static ArrayList<Resident> residents;
    public static ArrayList<Intervenant> intervenants;
    public static ArrayList<RequeteTravail> requetes;
    public static ArrayList<ProjetTravaux> projets;
    public static ArrayList<Entrave> entraves;
    public static ArrayList<Notification> notifications;
    public static String[] quartiers;
    public static ArrayList<String> TypeTravaux = new ArrayList<>();
    public static Map<String, ResidentService.IndexedEntity<Resident>> residentsMap;
    public static Map<String, IntervenantService.IndexedEntity<Intervenant>> intervenantsMap;
    public static Map<String, ProjetTravaux> projetsMap;
    public static Map<String, RequeteService.IndexedEntity<RequeteTravail>> requetesMap;

    public static void main(String[] args) throws IOException {
        //Scanner scanner = new Scanner(System.in);
        CentralAPI.main(args); // On lance le serveur pour activer l'API
        rafraichirDonnees();
        initialiserQuartiers();
        InterfaceApplication.main(args);

       // Menu menu = new Menu(residents, intervenants);
       // menu.afficher(scanner);
    }

    public static MaVille getInstance() {
        if (instance == null) {
            instance = new MaVille();
        }
        return instance;
    }

    public static void rafraichirDonnees() {
        try {
            residents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json",Resident.class);
            intervenants = (ArrayList<Intervenant>) UtilisateursAPI.readFromFile("src/main/resources/Intervenants.json",Intervenant.class);
            requetes = (ArrayList<RequeteTravail>) RequeteAPI.readFromFile("src/main/resources/requetes.json",RequeteTravail.class);
            projets =  ProjetEntravesService.getInstance().chargerProjetsDepuisApi();
            entraves = ProjetEntravesService.getInstance().chargerEntravesDepuisApi();
            notifications = (ArrayList<Notification>) NotificationAPI.readFromFile("src/main/resources/Notifications.json", Notification.class);
            residentsMap = ResidentService.getInstance().chargerResidentsEnMap();
            intervenantsMap = IntervenantService.getInstance().chargerIntervenantsEnMap();
            projetsMap = ProjetEntravesService.getInstance().chargerProjetsEnMap();
            requetesMap = RequeteService.getInstance().chargerRequetesEnMap();
            for(ProjetTravaux projet : projets){
                String typeTravaux = projet.getTypeTravaux();
                if(!MaVille.TypeTravaux.contains(typeTravaux)){
                    MaVille.TypeTravaux.add(typeTravaux);
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors du rafraîchissement des données de MaVille : " + e.getMessage());
        }
    }

    private static void initialiserQuartiers() {
        ArrayList<String> quartierArray = new ArrayList<>();
        quartierArray.add("Plateau-Mont-Royal");
        quartierArray.add("Rosemont–La Petite-Patrie");
        quartierArray.add("Outremont");
        quartierArray.add("Ville-Marie");
        quartierArray.add("Côte-des-Neiges–Notre-Dame-de-Grâce");
        quartierArray.add("Villeray–Saint-Michel–Parc-Extension");
        quartierArray.add("Hochelaga-Maisonneuve");
        quartierArray.add("Griffintown");
        quartierArray.add("Saint-Henri");
        quartierArray.add("Lachine");
        quartierArray.add("LaSalle");
        quartierArray.add("Ahuntsic-Cartierville");
        quartierArray.add("Montréal-Nord");
        quartierArray.add("Saint-Laurent");
        quartierArray.add("Anjou");
        quartierArray.add("Rivière-des-Prairies–Pointe-aux-Trembles");
        quartierArray.add("Mercier–Hochelaga-Maisonneuve");
        quartierArray.add("Verdun");
        quartierArray.add("Pierrefonds-Roxboro");
        quartierArray.add("Île-Bizard–Sainte-Geneviève");
        quartierArray.add("Sud-Ouest");
        quartiers = quartierArray.toArray(String[]::new);
    }
    public static class IndexedEntity<T> {
        public int index;
        public T entity;

        public IndexedEntity(int index, T entity) {
            this.index = index;
            this.entity = entity;
        }
    }
}
