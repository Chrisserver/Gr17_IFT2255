package org.example;

import java.util.ArrayList;

public class Resident {

    private String id;
    private String nomComplet;
    private String courriel;
    private String motDePasse;
    private String dateDeNaissance;
    private String telephone;
    private String adresseResidentielle;

    private String preferencesHoraires;

    private ArrayList<Notification> notifications;
    private String quartier;

    // Constructeur par défaut (requis pour Jackson)
    public Resident() {
    }

    // Constructeur avec arguments (optionnel si déjà utilisé ailleurs)
    public Resident(String nomComplet, String courriel, String motDePasse, String dateDeNaissance, String telephone, String adresseResidentielle,String quartier,String preferencesHoraires,String id, ArrayList<Notification> Notifications) {
        this.nomComplet = nomComplet;
        this.courriel = courriel;
        this.motDePasse = motDePasse;
        this.dateDeNaissance = dateDeNaissance;
        this.telephone = telephone;
        this.adresseResidentielle = adresseResidentielle;
        this.preferencesHoraires = preferencesHoraires;
        this.id = id;
        this.notifications = Notifications;
        this.quartier = quartier;
    }

    // Getters et Setters requis pour la sérialisation/désérialisation
    public String getNomComplet() { return nomComplet; }
    public void setNomComplet(String nomComplet) { this.nomComplet = nomComplet; }

    public String getCourriel() { return courriel; }
    public void setCourriel(String courriel) { this.courriel = courriel; }

    public String getMotDePasse() { return motDePasse; }
    public void setMotDePasse(String motDePasse) { this.motDePasse = motDePasse; }

    public String getDateDeNaissance() { return dateDeNaissance; }
    public void setDateDeNaissance(String dateDeNaissance) { this.dateDeNaissance = dateDeNaissance; }

    public String getTelephone() { return telephone; }
    public void setTelephone(String telephone) { this.telephone = telephone; }

    public String getAdresseResidentielle() { return adresseResidentielle; }
    public void setAdresseResidentielle(String adresseResidentielle) { this.adresseResidentielle = adresseResidentielle; }

    public String getPreferencesHoraires() {
        return preferencesHoraires;
    }

    public void setPreferencesHoraires(String preferencesHoraires) {
        this.preferencesHoraires = preferencesHoraires;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }
    public ArrayList<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(ArrayList<Notification> notifications) {
        this.notifications = notifications;
    }

    public String getQuartier() {
        return quartier;
    }

    public void setQuartier(String quartier) {
        this.quartier = quartier;
    }
}
