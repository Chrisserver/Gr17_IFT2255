package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.javalin.http.Context;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class RequeteAPI {
    public static  String FILE_PATH = "src/main/resources/requetes.json";
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void getRequetes(Context ctx) {
        List<RequeteTravail> requetes = readFromFile(FILE_PATH, RequeteTravail.class);
        if (requetes.isEmpty()) {
            ctx.status(404).json("Aucune requête trouvée");
        } else {
            ctx.status(200).json(requetes);
        }
    }

    public static void addRequete(Context ctx) {
        RequeteTravail requete = ctx.bodyAsClass(RequeteTravail.class);
        List<RequeteTravail> requetes = readFromFile(FILE_PATH, RequeteTravail.class);
        requetes.add(requete);
        writeToFile(FILE_PATH, requetes);
        ctx.status(201).result("Requête ajoutée avec succès !");
    }

    public static <T> List<T> readFromFile(String filePath, Class<T> entityType) {
        List<T> entities = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            StringBuilder jsonContent = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                jsonContent.append(line);
            }

            JSONArray jsonArray = new JSONArray(jsonContent.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (entityType == RequeteTravail.class) {
                    T entity = entityType.cast(new RequeteTravail(
                            jsonObject.getString("titreTravail"),
                            jsonObject.getString("descriptionDetaillee"),
                            jsonObject.getString("typeTravaux"),
                            jsonObject.getString("dateDebutEsperee"),
                            ProjetAPI.jsonArrayToArrayList(jsonObject.getJSONArray("candidatures")),
                            jsonObject.getString("ID"),
                            jsonObject.getString("residentID")
                    ));
                    entities.add(entity);
                }
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la lecture du fichier " + filePath + " : " + e.getMessage());
        }
        return entities;
    }

    public static <T> void writeToFile(String filePath, List<T> data) {
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            JSONArray jsonArray = new JSONArray();
            for (T entity : data) {
                if (entity instanceof RequeteTravail) {
                    RequeteTravail requete = (RequeteTravail) entity;
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("titreTravail", requete.getTitreTravail());
                    jsonObject.put("descriptionDetaillee", requete.getDescriptionDetaillee());
                    jsonObject.put("typeTravaux", requete.getTypeTravaux());
                    jsonObject.put("dateDebutEsperee", requete.getDateDebutEsperee());
                    jsonObject.put("candidatures", new ArrayList<>(requete.getCandidatures()));
                    jsonObject.put("ID", requete.getID());
                    jsonObject.put("residentID", requete.getResidentID());
                    jsonArray.put(jsonObject);
                }
            }
            fileWriter.write(jsonArray.toString(4)); // Indentation de 4 espaces
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture du fichier " + filePath + " : " + e.getMessage());
        }
    }
}
