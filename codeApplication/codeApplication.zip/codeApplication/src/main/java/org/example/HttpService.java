package org.example;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpService {


    public HttpService(){};
    /**
     * Effectue une requête HTTP POST avec les données spécifiées.
     *
     * @param urlString L'URL cible de la requête.
     * @param jsonPayload Les données à envoyer sous forme JSON.
     * @return Le code de réponse HTTP.
     * @throws Exception En cas d'erreur lors de la requête.
     */
    public int post(String urlString, String jsonPayload) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setDoOutput(true);

        try (OutputStream os = connection.getOutputStream()) {
            os.write(jsonPayload.getBytes());
            os.flush();
        }

        return connection.getResponseCode();
    }

    /**
     * Effectue une requête HTTP GET à une URL donnée.
     *
     * @param urlString L'URL cible de la requête.
     * @return Le corps de la réponse sous forme de chaîne.
     * @throws Exception En cas d'erreur lors de la requête.
     */
    public String get(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Content-Type", "application/json");

        try (var inputStream = connection.getInputStream();
             var scanner = new java.util.Scanner(inputStream, "UTF-8")) {
            return scanner.useDelimiter("\\A").next();
        }
    }
}
