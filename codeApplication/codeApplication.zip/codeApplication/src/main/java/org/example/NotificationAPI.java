package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.javalin.http.Context;

public class NotificationAPI {

    public static String FILE_PATH = "Notifications.json";
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void getNotifications(Context ctx) {
        List<Notification> notifications = readFromFile(FILE_PATH, Notification.class);
        if (notifications.isEmpty()) {
            ctx.status(404).json("Aucune notification trouvée");
        } else {
            ctx.status(200).json(notifications);
        }
    }

    public static void addNotification(Context ctx) {
        Notification notification = ctx.bodyAsClass(Notification.class);
        List<Notification> notifications = readFromFile(FILE_PATH, Notification.class);
        notifications.add(notification);
        writeToFile(FILE_PATH, notifications);
        ctx.status(201).result("Notification ajoutée avec succès !");
    }

    public static <T> List<T> readFromFile(String filePath, Class<T> entityType) {
        List<T> entities = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            StringBuilder jsonContent = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                jsonContent.append(line);
            }

            JSONArray jsonArray = new JSONArray(jsonContent.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (entityType == Notification.class) {
                    T entity = entityType.cast(new Notification(
                            jsonObject.getString("id"),
                            jsonObject.getString("idDocument"),
                            jsonObject.getString("idUtilisateur"),
                            jsonObject.getString("message"),
                            jsonObject.getString("titre")
                            
                    ));
                    entities.add(entity);
                }
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la lecture du fichier " + filePath + " : " + e.getMessage());
        }
        return entities;
    }

    public static <T> void writeToFile(String filePath, List<T> data) {
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            JSONArray jsonArray = new JSONArray();
            for (T entity : data) {
                if (entity instanceof Notification) {
                    Notification notification = (Notification) entity;
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("id", notification.getId());
                    jsonObject.put("idUtilisateur", notification.getIdUtilisateur());
                    jsonObject.put("titre", notification.getTitre());
                    jsonObject.put("message", notification.getMessage());
                    jsonObject.put("idDocument", notification.getIdDocument());
                    jsonObject.put("idDocument", notification.getVue());
                    jsonArray.put(jsonObject);
                }
            }
            fileWriter.write(jsonArray.toString(4)); // Indentation de 4 espaces
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture du fichier " + filePath + " : " + e.getMessage());
        }
    }
    
}
