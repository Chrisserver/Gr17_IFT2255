package org.example;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;

public class IntervenantMenu {
    private ArrayList<RequeteTravail> requetes = MaVille.requetes;
    private static String idIntervenant = Connexion.intervenantConnected.getIdentifiantVille();
    
        int indiceArray = MaVille.intervenantsMap.get(idIntervenant).index;
    
    
    
        public IntervenantMenu() {
    
        }
    
        public static void soumettreProjet(String titre, String description, String typeTravaux, ArrayList<String> quartiersAffectes, ArrayList<String> ruesAffectees, String dateDebut, String dateFin, String horaireTravaux) throws IOException {
    
            // Création de l'objet ProjetTravaux
            ProjetTravaux projet = new ProjetTravaux(
                idIntervenant, // Id de l'intervenant associé
                titre,
                description,
                typeTravaux,
                quartiersAffectes,
                ruesAffectees,
                dateDebut,
                dateFin,
                horaireTravaux,
                "Prévu"
        );

        try {
            URL url = new URL("http://localhost:7000/projets");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            Gson gson = new Gson();
            String jsonProjet = gson.toJson(projet);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonProjet.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == 201) {
                String message = "Un nouveau projet a été soumis dans votre quartier : " + projet.getTitre();
                ResidentService.getInstance().notifierResidentsParQuartier(projet.getQuartiersAffectes(), message);
                System.out.println("Projet soumis et notifications envoyées avec succès !");
            } else {
                System.out.println("Erreur lors de l'ajout du projet. Code : " + responseCode);
            }

        } catch (Exception e) {
            System.out.println("Une erreur s'est produite lors de la soumission du projet : " + e.getMessage());
        }

        // Mise à jour des projets dans MaVille
        MaVille.projets = ProjetEntravesService.getInstance().chargerProjetsDepuisApi();
    }



    private void consulterRequetes() {
        System.out.println("Consulter les requêtes de travail:");

        if (requetes.isEmpty()) {
            System.out.println("Aucune requête de travail disponible.");
        } else {
            int compteur = 0;
            for (RequeteTravail requete : requetes) {
                System.out.println("---- Requête " + compteur++ + " ----");
                System.out.println("Titre : " + requete.getTitreTravail());
                System.out.println("Description : " + requete.getDescriptionDetaillee());
                System.out.println("Type de travaux : " + requete.getTypeTravaux());
                System.out.println("Date début : " + requete.getDateDebutEsperee());
                System.out.println();
            }
        }
    }

    public void modifierStatut(Scanner scanner) throws IOException {
        System.out.println("Entrer nouveau statut");
        String statut = scanner.nextLine();
        List<ProjetTravaux> projets = MaVille.projets;
        for (int i = 0; i < projets.size(); i++) {
            if (projets.get(i).getId().equalsIgnoreCase(idIntervenant)) {
                ProjetTravaux projet = projets.get(i);
                projets.get(i).setStatut(statut);
                // Envoyer notifications
                String message = "Le statut du projet " + projet.getTitre() + " a été mis à jour : " + statut;
                ResidentService.getInstance().notifierResidentsParQuartier(projet.getQuartiersAffectes(), message);

            }
        }
        ;
        ProjetAPI.writeToFile("src/main/resources/Projets.json", projets);
        MaVille.projets = ProjetEntravesService.getInstance().chargerProjetsDepuisApi();


        System.out.println("Statut modifié et notifications envoyées.");


    }
    public void soumettreCandidature(Scanner scanner) {
        System.out.println("Entrez le numéro de la requête pour laquelle candidater:");
        consulterRequetes();

        if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine();
            if (choice >= 0 && choice < MaVille.requetes.size()) {
                RequeteTravail requeteChoisie = MaVille.requetes.get(choice);
                boolean success = addCandidature(requeteChoisie.getID(), idIntervenant);

                if (success) {
                    System.out.println("Candidature soumise avec succès !");
                } else {
                    System.out.println("Erreur lors de la soumission. Vérifiez les données.");
                }
            } else {
                System.out.println("Numéro de requête invalide.");
            }
        } else {
            System.out.println("Veuillez entrer un numéro valide.");
            scanner.nextLine();
        }
    }

    public void soustraireCandidature(Scanner scanner) {
        Intervenant intervenantConnected = MaVille.intervenants.get(indiceArray);
        ArrayList<String> requetesCandidate = intervenantConnected.getRequetesCandidate();

        System.out.println("Requêtes actuelles :");
        for (int i = 0; i < requetesCandidate.size(); i++) {
            System.out.println(i + ": " + requetesCandidate.get(i));
        }

        System.out.println("Entrez le numéro de la requête à retirer :");
        if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine();
            if (choice >= 0 && choice < requetesCandidate.size()) {
                boolean success = soustraireCandidature(requetesCandidate.get(choice), intervenantConnected.getIdentifiantVille());

                if (success) {
                    System.out.println("Candidature retirée avec succès !");
                } else {
                    System.out.println("Erreur lors de la suppression.");
                }
            } else {
                System.out.println("Numéro invalide.");
            }
        } else {
            System.out.println("Veuillez entrer un numéro valide.");
            scanner.nextLine();
        }
    }


    public static boolean addCandidature(String requeteID, String candidatID) {
        try {
            ArrayList<RequeteTravail> requetes = MaVille.requetes;
            ArrayList<Intervenant> intervenants = MaVille.intervenants;

            boolean updated = false;

            // Mise à jour de la requête
            for (RequeteTravail requete : requetes) {
                if (requete.getID().equals(requeteID)) {
                    ArrayList<String> candidatures = requete.getCandidatures();
                    if (!candidatures.contains(candidatID)) {
                        candidatures.add(candidatID);
                        requete.setCandidatures(candidatures);
                        updated = true;
                    }
                    break;
                }
            }

            // Mise à jour de l'intervenant
            for (Intervenant intervenant : intervenants) {
                if (intervenant.getIdentifiantVille().equals(candidatID)) {
                    ArrayList<String> requetesCandidate = intervenant.getRequetesCandidate();
                    if (!requetesCandidate.contains(requeteID)) {
                        requetesCandidate.add(requeteID);
                        intervenant.setRequetesCandidate(requetesCandidate);
                        updated = true;
                    }
                    break;
                }
            }

            // Sauvegarde des mises à jour
            if (updated) {
                RequeteAPI.writeToFile("src/main/resources/requetes.json", requetes);
                UtilisateursAPI.writeToFile("src/main/resources/Intervenants.json", intervenants);

                // Synchroniser MaVille
                MaVille.requetes = (ArrayList<RequeteTravail>) RequeteAPI.readFromFile("src/main/resources/requetes.json",RequeteTravail.class);
                MaVille.intervenants = (ArrayList<Intervenant>) UtilisateursAPI.readFromFile("src/main/resources/Intervenants.json", Intervenant.class);
            }

            return updated;
        } catch (Exception e) {
            System.out.println("Erreur lors de la mise à jour des candidatures : " + e.getMessage());
            return false;
        }
    }

    public static boolean soustraireCandidature(String requeteID, String candidatID) {
        try {
            ArrayList<RequeteTravail> requetes = MaVille.requetes;
            ArrayList<Intervenant> intervenants = MaVille.intervenants;

            boolean updated = false;

            // Suppression de la candidature dans la requête
            for (RequeteTravail requete : requetes) {
                if (requete.getID().equals(requeteID)) {
                    ArrayList<String> candidatures = requete.getCandidatures();
                    if (candidatures.contains(candidatID)) {
                        candidatures.remove(candidatID);
                        requete.setCandidatures(candidatures);
                        updated = true;
                    }
                    break;
                }
            }

            // Suppression de la requête dans l'intervenant
            for (Intervenant intervenant : intervenants) {
                if (intervenant.getIdentifiantVille().equals(candidatID)) {
                    ArrayList<String> requetesCandidate = intervenant.getRequetesCandidate();
                    if (requetesCandidate.contains(requeteID)) {
                        requetesCandidate.remove(requeteID);
                        intervenant.setRequetesCandidate(requetesCandidate);
                        updated = true;
                    }
                    break;
                }
            }

            // Sauvegarde des mises à jour
            if (updated) {
                RequeteAPI.writeToFile("src/main/resources/requetes.json", requetes);
                UtilisateursAPI.writeToFile("src/main/resources/Intervenants.json", intervenants);

                // Synchroniser MaVille
                MaVille.requetes = (ArrayList<RequeteTravail>) RequeteAPI.readFromFile("src/main/resources/requetes.json",RequeteTravail.class);
                MaVille.intervenants = (ArrayList<Intervenant>) UtilisateursAPI.readFromFile("src/main/resources/Intervenants.json", Intervenant.class);
            }

            return updated;
        } catch (Exception e) {
            System.out.println("Erreur lors de la suppression des candidatures : " + e.getMessage());
            return false;
        }
    }

    public void suivreCandidature(Scanner scanner) {
        Intervenant intervenantConnected = MaVille.intervenants.get(indiceArray);
        ArrayList<String> requetesCandidate = intervenantConnected.getRequetesCandidate();

        if (requetesCandidate.isEmpty()) {
            System.out.println("Vous n'avez aucune candidature en cours.");
            return;
        }

        System.out.println("Suivi des candidatures :");
        for (int i = 0; i < requetesCandidate.size(); i++) {
            String requeteID = requetesCandidate.get(i);
            RequeteTravail requete = MaVille.requetesMap.get(requeteID).entity;
            System.out.println(i + ". Titre : " + requete.getTitreTravail() + " | Type : " + requete.getTypeTravaux());
        }

        System.out.println("Entrez le numéro de la candidature pour afficher plus de détails (ou -1 pour quitter) :");
        int choix;
        if (scanner.hasNextInt()) {
            choix = scanner.nextInt();
            scanner.nextLine(); // Consomme la nouvelle ligne
            if (choix >= 0 && choix < requetesCandidate.size()) {
                String requeteID = requetesCandidate.get(choix);
                RequeteTravail requete = MaVille.requetesMap.get(requeteID).entity;
                afficherDetailsRequete(requete);
            } else if (choix == -1) {
                System.out.println("Retour au menu principal.");
            } else {
                System.out.println("Choix invalide. Veuillez réessayer.");
            }
        } else {
            System.out.println("Veuillez entrer un nombre valide.");
            scanner.nextLine(); // Consomme la nouvelle ligne
        }
    }

    private void afficherDetailsRequete(RequeteTravail requete) {
        System.out.println("---- Détails de la Requête ----");
        System.out.println("Titre : " + requete.getTitreTravail());
        System.out.println("Description : " + requete.getDescriptionDetaillee());
        System.out.println("Type de travaux : " + requete.getTypeTravaux());
        System.out.println("Date de début espérée : " + requete.getDateDebutEsperee());
        System.out.println("Nombre de candidatures : " + requete.getCandidatures().size());
        System.out.println("--------------------------------");
    }

}
