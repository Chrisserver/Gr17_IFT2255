package org.example;

import java.util.ArrayList;
import java.util.Arrays;

public class Intervenant {
    private String nomComplet;
    private String courriel;
    private String motDePasse;
    private String type;
    private String identifiantVille;

    private ArrayList<String> requetesCandidate = new ArrayList<>(Arrays.asList(""));


    // Constructeur par défault recquis pour Jacskon(ctx.bodyasClass() et mapper.readvalue())
    public Intervenant(){}

    public Intervenant(String nomComplet, String courriel, String motDePasse, String type, String identifiantVille,ArrayList<String> requetesCandidate) {
        this.nomComplet = nomComplet;
        this.courriel = courriel;
        this.motDePasse = motDePasse;
        this.type = type;
        this.identifiantVille = identifiantVille;
        this.requetesCandidate = requetesCandidate;
    }

    public String getNomComplet() {
        return this.nomComplet;
    }

    public String getCourriel() {
        return this.courriel;
    }

    public String getMotDePasse() {
        return this.motDePasse;
    }

    public String getType() {
        return this.type;
    }

    public String getIdentifiantVille() {
        return this.identifiantVille;
    }

    public ArrayList<String> getRequetesCandidate() {
        return requetesCandidate;
    }

    public void setRequetesCandidate(ArrayList<String> requetesCandidate) {
        this.requetesCandidate = requetesCandidate;
    }
}
