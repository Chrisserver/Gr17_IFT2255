package org.example;

import java.util.ArrayList;

public class RequeteTravail {

    private String ID;
    private String titreTravail;
    private String descriptionDetaillee;
    private String typeTravaux;
    private String dateDebutEsperee;
    private ArrayList<String> candidatures;
    private String residentID; // Nouveau champ residentID

    public RequeteTravail(String titreTravail, String descriptionDetaillee, String typeTravaux, String dateDebutEsperee, ArrayList<String> candidatures, String ID, String residentID) {
        this.titreTravail = titreTravail;
        this.descriptionDetaillee = descriptionDetaillee;
        this.typeTravaux = typeTravaux;
        this.dateDebutEsperee = dateDebutEsperee;
        this.candidatures = candidatures;
        this.ID = ID;
        this.residentID = residentID;
    }

    public String getTitreTravail() {
        return this.titreTravail;
    }

    public void setTitreTravail(String titreTravail) {
        this.titreTravail = titreTravail;
    }

    public String getDescriptionDetaillee() {
        return this.descriptionDetaillee;
    }

    public void setDescriptionDetaillee(String descriptionDetaillee) {
        this.descriptionDetaillee = descriptionDetaillee;
    }

    public String getTypeTravaux() {
        return this.typeTravaux;
    }

    public void setTypeTravaux(String typeTravaux) {
        this.typeTravaux = typeTravaux;
    }

    public String getDateDebutEsperee() {
        return this.dateDebutEsperee;
    }

    public void setDateDebutEsperee(String dateDebutEsperee) {
        this.dateDebutEsperee = dateDebutEsperee;
    }

    public ArrayList<String> getCandidatures() {
        return this.candidatures;
    }

    public void setCandidatures(ArrayList<String> candidatures) {
        this.candidatures = candidatures;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getResidentID() {
        return residentID;
    }

    public void setResidentID(String residentID) {
        this.residentID = residentID;
    }
}
