package org.example;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

class IntervenantService {
    private static IntervenantService instance;
    private final ArrayList<Intervenant> intervenants = new ArrayList<>();

    private IntervenantService() {
    }

    public static IntervenantService getInstance() {
        if (instance == null) {
            instance = new IntervenantService();
        }
        return instance;
    }

    public ArrayList<Intervenant> chargerIntervenantsDepuisApi() throws IOException {
        intervenants.clear();
        String url = "http://localhost:7000/intervenants";
        HttpResponse<String> response = HttpClientMaVille.get(url);
        if (response != null && response.statusCode() == 200) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<Intervenant>>() {}.getType();
            ArrayList<Intervenant> newIntervenants = gson.fromJson(response.body(), type);
            intervenants.addAll(newIntervenants);
            return intervenants;
        }
        System.out.println("Erreur de récupération des intervenants.");
        return intervenants;
    }
    public Map<String, IndexedEntity<Intervenant>> chargerIntervenantsEnMap() throws IOException {
        ArrayList<Intervenant> listeIntervenants = chargerIntervenantsDepuisApi();
        return convertirEnMap(listeIntervenants);
    }

    private Map<String, IndexedEntity<Intervenant>> convertirEnMap(ArrayList<Intervenant> liste) {
        Map<String, IndexedEntity<Intervenant>> map = new HashMap<>();
        for (int i = 0; i < liste.size(); i++) {
            Intervenant intervenant = liste.get(i);
            map.put(intervenant.getIdentifiantVille(), new IndexedEntity<>(i, intervenant));
        }
        return map;
    }

    public static class IndexedEntity<T> {
        public int index;
        public T entity;

        public IndexedEntity(int index, T entity) {
            this.index = index;
            this.entity = entity;
        }
    }
}