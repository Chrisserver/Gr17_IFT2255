package org.example;


import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class ResidentMenu {
    private String idResident = Connexion.residentConnected.getID();

    int indiceArray = MaVille.residentsMap.get(idResident).index;
    public ResidentMenu() {
    }


    public void afficherMenu(Scanner scanner) throws IOException {
        int choice = -1;

        while(choice != 0) {
            System.out.println("----Menu Résident---");
            System.out.println("Choisissez une option:");
            System.out.println("1. Consulter les travaux en cours ou à venir");
            System.out.println("2.Consulter les entraves associées aux travaux en cours");
            System.out.println("3. Voir notifications");
            System.out.println("4. Soumettre une requête de travail");
            System.out.println("5. Faire le suivi d'une requête");
            System.out.println("6. Modifier Préférences Horaires");
            System.out.println("0. Se déconnecter");
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine();
            } else {
                System.out.println("Veuillez entrer un nombre valide");
                scanner.nextLine();
                continue;
            }

            switch (choice) {
                case 1:
                    this.consulterTravaux();
                    break;
                case 2:
                    this.consulterEntraves();
                    break;
                case 3:
                    this.voirNotifications();
                    break;
                case 6:
                    this.modifierPreferencesHoraires(scanner);
                    break;
                case 5:
                    this.suivreRequetes(scanner);
                    break;
                case 0:
                    System.out.println("Déconnexion...");
                    break;
                default:
                    System.out.println("Option invalide. Veuillez réessayer.");
            }
        }

    }

    private void consulterTravaux() {
        ArrayList<ProjetTravaux> projets = MaVille.projets;
        LocalDate aujourdHui = LocalDate.now();
        LocalDate dansTroisMois = aujourdHui.plusMonths(3);
        int compteur = 1;

        Scanner scanner = new Scanner(System.in);
        ArrayList<ProjetTravaux> projetsFiltrables = new ArrayList<>();

        System.out.println("Travaux prévus dans les trois prochains mois :");
        for (ProjetTravaux projet : projets) {
            LocalDate dateFin = LocalDate.parse(projet.getDateFin(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            if (dateFin.isBefore(dansTroisMois) && dateFin.isAfter(aujourdHui)) {
                afficherUnProjet(projet, compteur++);
                projetsFiltrables.add(projet); // Ajouter aux projets filtrables
            }
        }

        if (compteur == 1) {
            System.out.println("Aucun projet prévu dans les trois prochains mois.");
            return;
        }
        int choix = -1;
        while(choix!=3){
        System.out.println("\nVoulez-vous filtrer les travaux ?");
        System.out.println("1. Par quartier");
        System.out.println("2. Par type de travaux");
        System.out.println("3. Retourner au menu principal");
        if(scanner.hasNextInt()){
        choix = scanner.nextInt();
        scanner.nextLine();// Consommer le saut de ligne
        }else{
            System.out.println("Veuillez entrer un nombre valide (1, 2 ou 3).");
            scanner.nextLine();// Consommer le saut de ligne
            continue;

        }

        switch (choix) {
            case 1:
                System.out.println("Quartiers disponibles :");
                int count2 = 0;
                String quartierChoisi ="";
                for (String quartier : MaVille.quartiers) {
                    System.out.println(count2++ +". " + quartier);
                }

                while (true) {
                    System.out.println("Entrez le quartier:");
                    int count3 = 0;

                    // Affichage des options disponibles
                    for (String quartier : MaVille.quartiers) {
                        System.out.println(count3++ + ". " + quartier);
                    }

                    if (scanner.hasNextInt()) {
                        int choix2 = scanner.nextInt();
                        scanner.nextLine(); // Consomme la ligne restante

                        // Vérifie si le choix est dans les limites valides
                        if (choix2 >= 0 && choix2 < MaVille.quartiers.length) {
                            quartierChoisi = MaVille.quartiers[choix2];
                            break; // Sort de la boucle une fois que l'entrée est valide
                        } else {
                            System.out.println("Veuillez entrer un nombre entre 0 et " + (MaVille.quartiers.length - 1) + ".");
                        }
                    } else {
                        System.out.println("Entrée invalide. Veuillez entrer un nombre.");
                        scanner.nextLine(); // Consomme la ligne restante pour éviter une boucle infinie
                    }}

                ArrayList<ProjetTravaux> travauxParQuartier = new ArrayList<>();
                for (ProjetTravaux projet : projetsFiltrables) {
                    if (projet.getQuartiersAffectes().contains(quartierChoisi)) {
                        travauxParQuartier.add(projet);
                    }
                }
                afficherTravauxFiltres(travauxParQuartier, "quartier : " + quartierChoisi);
                break;

            case 2:
                System.out.println("Types de travaux disponibles :");
                int count = 0;
                String typeChoisi ="";
                for (String type : MaVille.TypeTravaux) {
                    System.out.println(count++ +". " + type);
                }

                while (true) {
                    System.out.println("Entrez le Type de travaux :");
                    int count1 = 0;

                    // Affichage des options disponibles
                    for (String type : MaVille.TypeTravaux) {
                        System.out.println(count1++ + ". " + type);
                    }

                    if (scanner.hasNextInt()) {
                        int choix1 = scanner.nextInt();
                        scanner.nextLine(); // Consomme la ligne restante

                        // Vérifie si le choix est dans les limites valides
                        if (choix1 >= 0 && choix1 < MaVille.TypeTravaux.size()) {
                             typeChoisi = MaVille.TypeTravaux.get(choix1);
                            break; // Sort de la boucle une fois que l'entrée est valide
                        } else {
                            System.out.println("Veuillez entrer un nombre entre 0 et " + (MaVille.TypeTravaux.size() - 1) + ".");
                        }
                    } else {
                        System.out.println("Entrée invalide. Veuillez entrer un nombre.");
                        scanner.nextLine(); // Consomme la ligne restante pour éviter une boucle infinie
                    }}

                ArrayList<ProjetTravaux> travauxParType = new ArrayList<>();
                for (ProjetTravaux projet : projetsFiltrables) {
                    if (projet.getTypeTravaux().equalsIgnoreCase(typeChoisi)) {
                        travauxParType.add(projet);
                    }
                }
                afficherTravauxFiltres(travauxParType, "type de travaux : " + typeChoisi);
                break;

            case 3:
                System.out.println("Retour au menu principal.");
                return;

            default:
                System.out.println("Choix invalide.");
        }
    }
    }

    // Méthode pour afficher les projets filtrés
    private void afficherTravauxFiltres(ArrayList<ProjetTravaux> travauxFiltres, String critere) {
        if (travauxFiltres.isEmpty()) {
            System.out.println("Aucun projet trouvé pour le critère " + critere + ".");
        } else {
            System.out.println("Travaux filtrés par " + critere + " :");
            int compteur = 1;
            for (ProjetTravaux projet : travauxFiltres) {
                afficherUnProjet(projet, compteur++);
            }
        }
    }

    public void consulterEntraves() {
        int count = 0;
        for(Entrave entrave:MaVille.entraves)
            this.afficherUneEntrave(entrave, count++);
        menuRechercheEntraves();
            }

     public void  modifierPreferencesHoraires(Scanner scanner) throws IOException {
        ArrayList<Resident> residents = MaVille.residents;
        System.out.println("Entrer nouvelles préférences Horaires(exemple format:8h-17h):");
        residents.get(indiceArray).setPreferencesHoraires(scanner.nextLine());
         UtilisateursAPI.writeToFile("src/main/resources/Residents.json",residents);// On met a jour la base de données
         MaVille.residents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json",Resident.class);


     };


    public void chercherEntravesParTravail(String idTravail) {
        boolean trouve = false;
        for (Entrave entrave : MaVille.entraves) {
            if (entrave.getIdRequest().equals(idTravail)) {
                this.afficherUneEntrave(entrave, 1); // Affiche l'entrave trouvée
                trouve = true;
            }
        }
        if (!trouve) {
            System.out.println("Aucune entrave associée au travail avec l'ID : " + idTravail);
        }
    }

    public void chercherEntravesParRue(String streetId) {
        boolean trouve = false;
        for (Entrave entrave : MaVille.entraves) {
            if (entrave.getStreetId().equalsIgnoreCase(streetId)) {
                this.afficherUneEntrave(entrave, 1); // Affiche l'entrave trouvée
                trouve = true;
            }
        }
        if (!trouve) {
            System.out.println("Aucune entrave trouvée pour la rue avec l'ID : " + streetId);
        }
    };

    public void menuRechercheEntraves() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Options de recherche d'entraves :");
            System.out.println("1. Rechercher par ID de travail");
            System.out.println("2. Rechercher par ID de rue");
            System.out.println("3. Retour au menu principal");
            int choix;
            if (scanner.hasNextInt()) {
                choix = scanner.nextInt();
                scanner.nextLine();// Consomme la nouvelle ligne
            } else {
                System.out.println("Veuillez entrer un nombre valide (1, 2 ou 3).");
                scanner.nextLine();// Consommer le saut de ligne
                continue;
            }

            switch (choix) {
                case 1:
                    System.out.println("Entrez l'ID du travail :");
                    String idTravail = scanner.nextLine();
                    chercherEntravesParTravail(idTravail);
                    break;
                case 2:
                    System.out.println("Entrez l'ID de la rue :");
                    String streetId = scanner.nextLine();
                    chercherEntravesParRue(streetId);
                    break;
                case 3:
                    return; // Quitte le sous-menu
                default:
                    System.out.println("Option invalide. Veuillez réessayer.");
            }
        }
    }


    public static void soumettreRequete(String titre, String description, String type, String dateDebut) throws IOException {
        String residentID = Connexion.residentConnected.getID(); // Récupérer l'ID du résident connecté

        String jsonRequete = String.format(
                "{\"ID\":\"%s\", \"titreTravail\":\"%s\", \"descriptionDetaillee\":\"%s\", \"typeTravaux\":\"%s\", \"dateDebutEsperee\":\"%s\", \"residentID\":\"%s\"}",
                UUID.randomUUID().toString(), titre, description, type, dateDebut, residentID
        );

        try {
            URL url = new URL("http://localhost:7000/requetes");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonRequete.getBytes());
                os.flush();
            }

            int responseCode = connection.getResponseCode();
        } catch (Exception e) {
            e.printStackTrace();
        }
        MaVille.requetes = (ArrayList<RequeteTravail>) RequeteAPI.readFromFile("src/main/resources/requetes.json",RequeteTravail.class);
    }


    
    public void voirNotifications() {
        Resident resident = Connexion.residentConnected;
        ArrayList<Notification> notifications = resident.getNotifications();

        if (notifications.isEmpty()) {
            System.out.println("Vous n'avez aucune notification.");
            return;
        }

        System.out.println("Vos notifications :");
        for (Notification notification : notifications) {
           if(!notification.getVue()){
            System.out.println("- " + notification.getMessage());
            notification.setVue(true); // Marquer comme lue
        }}

        // Mise à jour du fichier JSON
        UtilisateursAPI.writeToFile("src/main/resources/Residents.json", MaVille.residents);
    };


    public void afficherUnProjet(ProjetTravaux projet, int id) {
        System.out.println("--- Projet " + id + " ---");
        System.out.println("Titre : " + projet.getTitre());
        System.out.println("Description : " + projet.getDescription());
        System.out.println("Quartiers affectés : " + String.join(", ", projet.getQuartiersAffectes()));
        System.out.println("Rues affectées : " + String.join(", ", projet.getRuesAffectees()));
        PrintStream var10000 = System.out;
        String var10001 = projet.getDateDebut();
        var10000.println("Dates : " + var10001 + " au " + projet.getDateFin());
        System.out.println("Type de travaux : " + projet.getTypeTravaux());
        System.out.println("Horaire des travaux : " + projet.getHoraireTravaux());
    }

    public void afficherUneEntrave(Entrave entrave, int count) {
        System.out.println("--- Entrave " + count + " ---");
        System.out.println("Rue : " + entrave.getShortName());
        System.out.println("Type d'impact : " + entrave.getStreetImpactType());
        System.out.println("ID de la rue : " + entrave.getStreetId());
        System.out.println("Identifiant de travail du projet lié : " + entrave.getIdRequest());
    }
    public void suivreRequetes(Scanner scanner) {
        String residentID = Connexion.residentConnected.getID();
        List<RequeteTravail> requetes = MaVille.requetes;

        System.out.println("Vos requêtes :");
        int compteur = 0;
        for (RequeteTravail requete : requetes) {
            if (requete.getResidentID().equals(residentID)) {
                System.out.println(compteur++ + ". Titre : " + requete.getTitreTravail() + " | Type : " + requete.getTypeTravaux());
            }
        }

        if (compteur == 0) {
            System.out.println("Vous n'avez soumis aucune requête.");
            return;
        }

        System.out.println("Entrez le numéro de la requête pour afficher plus de détails (ou -1 pour quitter) :");
        int choix;
        if (scanner.hasNextInt()) {
            choix = scanner.nextInt();
            scanner.nextLine(); // Consomme la nouvelle ligne
            if (choix >= 0 && choix < compteur) {
                RequeteTravail requete = requetes.get(choix);
                afficherDetailsRequete(requete);
            } else if (choix == -1) {
                System.out.println("Retour au menu principal.");
            } else {
                System.out.println("Choix invalide. Veuillez réessayer.");
            }
        } else {
            System.out.println("Veuillez entrer un nombre valide.");
            scanner.nextLine(); // Consomme la nouvelle ligne
        }
    }

    private void afficherDetailsRequete(RequeteTravail requete) {
        System.out.println("---- Détails de la Requête ----");
        System.out.println("Titre : " + requete.getTitreTravail());
        System.out.println("Description : " + requete.getDescriptionDetaillee());
        System.out.println("Type de travaux : " + requete.getTypeTravaux());
        System.out.println("Date de début espérée : " + requete.getDateDebutEsperee());
        System.out.println("Nombre de candidatures : " + requete.getCandidatures().size());
        System.out.println("--------------------------------");
    }

}
