package org.example;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Toolkit;
import java.io.IOException;
import static java.lang.Math.max;
import static java.lang.Math.min;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JWindow;
import javax.swing.ListSelectionModel;

public class InterfaceApplication {

    private static MaVille app = MaVille.getInstance();

    private static JFrame frame;
    private static CardLayout cardLayout;
    private static ImagePanel cardPanel;

    private static ImagePanel homePanel;
    private static ImagePanel profilIntervenantPanel;
    private static ImagePanel profilResidentPanel;
    private static ImagePanel connectionPanel;
    private static ImagePanel inscriptionPanel;
    private static ImagePanel menuIntervenantPanel;
    private static ImagePanel menuResidentPanel;

    private static String idUtilisateur;

    public static void main(String[] args) {
        showSplashScreen();
    }

    public static void showMainApplication() {

        /* -------------------Frame General------------------- */

        frame = new JFrame("Multi-Page Application");
        frame.setSize(1000, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        cardPanel = new ImagePanel(cardLayout);
        cardPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        cardPanel.setBackground(Color.LIGHT_GRAY); // Set the background color to cyan
        //cardPanel.setLayout(new CardLayout());

        /* -----------------------Pages----------------------- */

        homePanel();
        profilIntervenantPanel();
        profilResidentPanel();
        connectionPanel();
        inscriptionPanel();
        menuIntervenantPanel();
        menuResidentPanel();


        /* ----------------Ajout des scenes-------------------- */

        cardPanel.add(homePanel, "Home");
        cardPanel.add(profilIntervenantPanel, "ProfilIntervenant");
        cardPanel.add(profilResidentPanel, "ProfilResident");
        cardPanel.add(connectionPanel, "Connection");
        cardPanel.add(inscriptionPanel, "Inscription");
        cardPanel.add(menuIntervenantPanel, "MenuIntervenant");
        cardPanel.add(menuResidentPanel, "MenuResident");


        /* -----------------Affichage Final---------------------- */
        frame.setLayout(new BorderLayout());
        frame.add(cardPanel, BorderLayout.CENTER);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */

    private static void homePanel() {
        homePanel = new ImagePanel();
        homePanel.setLayout(new BoxLayout(homePanel, BoxLayout.Y_AXIS));
        JButton goToInscription = new JButton("S'inscrire");
        JButton goToConnection = new JButton("Se connecter");
        JButton exitPage = new JButton("Quitter");    


        ArrayList<JComponent> componentsHome = new ArrayList<>(
                Arrays.asList(new JLabel("Bienvenue au portail d'entrée"), goToInscription, goToConnection, exitPage));

        homePanel.showOnPanel(componentsHome);


        goToInscription.addActionListener(e ->
                cardLayout.show(cardPanel, "Inscription")
        );
        goToConnection.addActionListener(e ->
                cardLayout.show(cardPanel, "Connection")
        );
        exitPage.addActionListener(e ->
                System.exit(0)
        );
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */


    private static void profilIntervenantPanel() {
        profilIntervenantPanel = new ImagePanel();
        profilIntervenantPanel.setLayout(new BoxLayout(profilIntervenantPanel, BoxLayout.Y_AXIS));
        JButton disconnection = new JButton("Déconnexion");
        JButton goToMenu = new JButton("Retour au menu");
        String[] options = {"Requêtes enregistrées", "Mes projets de travaux", "Notification(s)"};
        JComboBox<String> comboProfil = new JComboBox<>(options);
        comboProfil.setMaximumSize(new Dimension(max(300,frame.getWidth()/3), 30));

        ArrayList<JComponent> componentsProfile = new ArrayList<>(
                Arrays.asList(new JLabel("Page profil intervenant"), comboProfil, disconnection, goToMenu));

        profilIntervenantPanel.showOnPanel(componentsProfile);


        comboProfil.addActionListener(e -> {
            int r = comboProfil.getSelectedIndex();
            profilIntervenantPanel.removeAll();
            switch (r) {
                case 0 -> { // Requêtes enregistrées
                    // Ajouter les valeurs de la base de données dans une liste
                    //      ArrayList<String[]> requetesBD = getBaseDeDonneesRequetesInfos(les id des requêtes);

                    ArrayList<Intervenant> intervenants = MaVille.intervenants;
                    Intervenant intervenantRecherche = null;
                    for (Intervenant intervenant:intervenants) {
                        if ((intervenant.getIdentifiantVille()).equals(idUtilisateur)) {
                            intervenantRecherche=intervenant;
                            break;
                        }
                    }

                    ArrayList<String> requetesID = intervenantRecherche.getRequetesCandidate();
                    
                    ArrayList<RequeteTravail> requeteTravailsBD = MaVille.requetes;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    for (RequeteTravail item : requeteTravailsBD) {
                        for (String ids : requetesID) {
                            if (ids.equals(item.getID())) {
                                listModel.addElement(item.getTitreTravail());
                                break;
                            }
                        }
                    }

                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

                    // Lorsqu'un intervenant appuye sur une requête, il affiche un message de la requête et de son contenu

                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            RequeteTravail projetChoisi = requeteTravailsBD.get(numberSelected);
                            String typeTravauxLabel = projetChoisi.getTypeTravaux();
                            String dateDebutLabel = projetChoisi.getDateDebutEsperee();
                            String descriptionLabel = projetChoisi.getDescriptionDetaillee();
                            String candidaturesLabel = String.join(", ", projetChoisi.getCandidatures());
                            String[] optionsCandidat = {"Soustraire sa candidature", "Quitter"};

                            if (titreProjet != null) {
                                int choice = JOptionPane.showOptionDialog(
                                        frame,
                                        "Travail #" + numberSelected +  "\nTitre du travail: " + titreProjet + "\nDate de début: " + dateDebutLabel +
                                                "\nType de travaux: " + typeTravauxLabel + "\nDescription: " + descriptionLabel + "\nCandidatures: " + candidaturesLabel,                                        
                                                "Item Selected",
                                                JOptionPane.YES_NO_OPTION,
                                                JOptionPane.QUESTION_MESSAGE,
                                                null,
                                                optionsCandidat,
                                                optionsCandidat[0]
                                );

                                switch (choice) {
                                    case 0 -> {
                                        ActionProvider.soustraireCandidature(projetChoisi.getID(), idUtilisateur);
                                    }
                                    case 1 -> {}
                                    default -> throw new AssertionError();
                                }
                            }
                        }
                    });


                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsIntervenant = new ArrayList<>(
                            Arrays.asList(componentsProfile.get(0), componentsProfile.get(1), scrollPane, disconnection, goToMenu));

                    profilIntervenantPanel.showOnPanel(componentsIntervenant);
                }
                case 1 -> { // Mes projets de travaux
                    // Accéder aux id de l'intervenant pour ces projets de travaux
                    Map<String, ProjetTravaux> projetsTravauxBD = MaVille.projetsMap;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    Map<String, String> travaux_ID_Titre = new HashMap<>();
                    for (String item : projetsTravauxBD.keySet()) {
                        ProjetTravaux inst = projetsTravauxBD.get(item);
                        // intervenantVoulu.getIdentifiantVille().equals(inst.getIdIntervenant()) {}
                        travaux_ID_Titre.put(inst.getTitre(), inst.getId());
                        listModel.addElement(inst.getTitre());
                    }


                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            String idProjet = travaux_ID_Titre.get(titreProjet);
                            ProjetTravaux projetChoisi = projetsTravauxBD.get(idProjet);
                            String typeTravauxLabel = projetChoisi.getTypeTravaux();
                            ArrayList<String> quartiersAffectesLabel = projetChoisi.getQuartiersAffectes();
                            ArrayList<String> rueAffecteesLabel = projetChoisi.getRuesAffectees();
                            String dateDebutLabel = projetChoisi.getDateDebut();
                            String dateFinLabel = projetChoisi.getDateFin();
                            String horaireTravauxLabel = projetChoisi.getHoraireTravaux();

                            if (titreProjet != null) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Travail #" + numberSelected +  "\nTitre du travail: " + titreProjet +
                                                "\nType de travaux: " + typeTravauxLabel + "\nQuartiers affectés: " + quartiersAffectesLabel + "\nRues affectées: " + rueAffecteesLabel +
                                                "\nDate de début: " + dateDebutLabel + "\nDate de fin: " + dateFinLabel + "\nHoraire de travaux: " + horaireTravauxLabel,
                                        "Item Selected",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                        }
                    });

                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsIntervenant = new ArrayList<>(
                            Arrays.asList(componentsProfile.get(0), componentsProfile.get(1), scrollPane, disconnection, goToMenu));

                    profilIntervenantPanel.showOnPanel(componentsIntervenant);
                }
                case 2 -> { // Notifications
                    // Accéder aux id de l'intervenant pour ces notifications
                    
                    ArrayList<Notification> notificationsBD = MaVille.notifications;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    for (Notification item : notificationsBD) {
                        if ((idUtilisateur).equals(item.getIdUtilisateur())) {
                            listModel.addElement(item.getTitre());
                            break;
                        }
                    }

                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            String titreProjet = itemList.getSelectedValue();
                            int numberSelected = itemList.getSelectedIndex();
                            Notification detailsDuTravail = notificationsBD.get(numberSelected);
                            String message = detailsDuTravail.getMessage();
                            ProjetTravaux projetTravaux = null;
                            RequeteTravail requeteTravail = null;
                            boolean estTrouve = false;

                            for (RequeteTravail requete : MaVille.requetes) {
                                if (detailsDuTravail.getIdDocument().equals(requete.getID())) {
                                    requeteTravail = requete;
                                    estTrouve = true;
                                    break;
                                }
                            }

                            if (estTrouve) {
                                
                                String typeTravauxLabel = requeteTravail.getTypeTravaux();
                                String dateDebutLabel = requeteTravail.getDateDebutEsperee();
                                String descriptionLabel = requeteTravail.getDescriptionDetaillee();
                                String candidaturesLabel = String.join(", ", requeteTravail.getCandidatures());

                                if (titreProjet != null) {
                                    JOptionPane.showMessageDialog(
                                            frame,
                                            "Notification Résident #" + numberSelected +  "\nTitre de la notification: " + titreProjet + "\nDescription: " + message + 
                                                "\nTitre du travail: " + titreProjet + "\nDate de début: " + dateDebutLabel +
                                                "\nType de travaux: " + typeTravauxLabel + "\nDescription: " + descriptionLabel + "\nCandidatures: " + candidaturesLabel,
                                            "Item Selected",
                                            JOptionPane.INFORMATION_MESSAGE
                                    );
                                }
                            } else {
                                for (ProjetTravaux projet : MaVille.projets) {
                                    if (detailsDuTravail.getIdDocument().equals(projet.getId())) {
                                        projetTravaux = projet;
                                        estTrouve = true;
                                        break;
                                    }
                                }

                                if (estTrouve) {
                                    String typeTravauxLabel = projetTravaux.getTypeTravaux();
                                    ArrayList<String> quartiersAffectesLabel = projetTravaux.getQuartiersAffectes();
                                    ArrayList<String> rueAffecteesLabel = projetTravaux.getRuesAffectees();
                                    String dateDebutLabel = projetTravaux.getDateDebut();
                                    String dateFinLabel = projetTravaux.getDateFin();
                                    String horaireTravauxLabel = projetTravaux.getHoraireTravaux();

                                    if (titreProjet != null) {
                                        JOptionPane.showMessageDialog(
                                                frame,
                                                "Notification Intervenant #" + numberSelected +  "\nTitre de la notification: " + titreProjet + "\nDescription: " + message +
                                                    "\nTitre du travail: " + titreProjet +
                                                    "\nType de travaux: " + typeTravauxLabel + "\nQuartiers affectés: " + quartiersAffectesLabel + "\nRues affectées: " + rueAffecteesLabel +
                                                    "\nDate de début: " + dateDebutLabel + "\nDate de fin: " + dateFinLabel + "\nHoraire de travaux: " + horaireTravauxLabel,
                                                "Item Selected",
                                                JOptionPane.INFORMATION_MESSAGE
                                        );
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(
                                                frame,
                                                "Le projet n'a pas pu être trouvé",
                                                "Erreur",
                                                JOptionPane.ERROR_MESSAGE
                                        );
                                }


                            }
                        }
                    });

                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsIntervenant = new ArrayList<>(
                            Arrays.asList(componentsProfile.get(0), componentsProfile.get(1), scrollPane, disconnection, goToMenu));

                    profilIntervenantPanel.showOnPanel(componentsIntervenant);
                }
                default -> throw new AssertionError();
            }
            profilIntervenantPanel.revalidate();
            profilIntervenantPanel.repaint();
        });

        disconnection.addActionListener(e ->
                cardLayout.show(cardPanel, "Home")
        );
        goToMenu.addActionListener(e ->
                cardLayout.show(cardPanel, "MenuIntervenant")
        );
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */


    private static void profilResidentPanel() {
        profilResidentPanel = new ImagePanel();
        profilResidentPanel.setLayout(new BoxLayout(profilResidentPanel, BoxLayout.Y_AXIS));
        JButton disconnection = new JButton("Déconnexion");
        JButton goToMenu = new JButton("Retour au menu");
        String[] options = {"Requêtes personnelles", "Notification(s)"};
        JComboBox<String> comboProfil = new JComboBox<>(options);
        comboProfil.setMaximumSize(new Dimension(max(300,frame.getWidth()/3), 30));

        ArrayList<JComponent> componentsProfile = new ArrayList<>(
                Arrays.asList(new JLabel("Profil résident"), comboProfil, disconnection, goToMenu));

        profilResidentPanel.showOnPanel(componentsProfile);

        comboProfil.addActionListener(e -> {
            int r = comboProfil.getSelectedIndex();
            profilResidentPanel.removeAll();
            Resident resides = null;
            ArrayList<Resident> residents = MaVille.residents;
            for (Resident resid : residents) {
                if (resid.getID().equals(idUtilisateur)) {
                    resides=resid;
                    break;
                }
            }
            final Resident resident = resides;

            switch (r) {
                case 0 -> { // Requêtes personnelles
                    // Ajouter les valeurs de la base de données dans une liste
                    
                    ArrayList<RequeteTravail> requeteTravailsBD = MaVille.requetes;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    for (RequeteTravail item : requeteTravailsBD) {
                        if (item.getResidentID().equals(idUtilisateur)) {
                            listModel.addElement(item.getTitreTravail());
                        }
                    }

                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

                    // Lorsqu'un intervenant appuye sur une requête, il affiche un message de la requête et de son contenu

                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            RequeteTravail projetChoisi = requeteTravailsBD.get(numberSelected);
                            String typeTravauxLabel = projetChoisi.getTypeTravaux();
                            String dateDebutLabel = projetChoisi.getDateDebutEsperee();
                            String descriptionLabel = projetChoisi.getDescriptionDetaillee();
                            String candidaturesLabel = String.join(", ", projetChoisi.getCandidatures());

                            if (titreProjet != null) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Travail #" + numberSelected +  "\nTitre du travail: " + titreProjet + "\nDate de début: " + dateDebutLabel +
                                                "\nType de travaux: " + typeTravauxLabel + "\nDescription: " + descriptionLabel + "\nCandidatures: " + candidaturesLabel,                                        "Item Selected",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                        }
                    });


                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsProfile.get(0), componentsProfile.get(1), scrollPane, disconnection, goToMenu));

                    profilResidentPanel.showOnPanel(componentsResident);
                }
                case 1 -> { // Notifications
                    // Accéder aux id de l'intervenant pour ces notifications

                    ArrayList<Notification> notificationsBD = MaVille.notifications;
                    ArrayList<Notification> notifsResident = resident.getNotifications();

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    ArrayList<Notification> titreNotifications = new ArrayList<>();
                    if (!notifsResident.isEmpty()) {
                        for (Notification item : notificationsBD) {
                            for (Notification notif : notifsResident) {
                                if ((idUtilisateur).equals(item.getIdUtilisateur()) && !(notif.getVue())) {
                                    listModel.addElement(item.getTitre());
                                    titreNotifications.add(item);
                                    break;
                                }
                            }
                        }
                    }

                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            String titreProjet = itemList.getSelectedValue();
                            int numberSelected = itemList.getSelectedIndex();
                            Notification detailsDuTravail = titreNotifications.get(numberSelected);
                            String message = detailsDuTravail.getMessage();
                            ProjetTravaux projetTravaux = null;
                            RequeteTravail requeteTravail = null;
                            boolean estTrouve = false;
                            
                            ActionProvider.voirNotifications(resident, detailsDuTravail);

                            for (RequeteTravail requete : MaVille.requetes) {
                                if (detailsDuTravail.getIdDocument().equals(requete.getID())) {
                                    requeteTravail = requete;
                                    estTrouve = true;
                                    break;
                                }
                            }

                            if (estTrouve) {
                                
                                String typeTravauxLabel = requeteTravail.getTypeTravaux();
                                String dateDebutLabel = requeteTravail.getDateDebutEsperee();
                                String descriptionLabel = requeteTravail.getDescriptionDetaillee();
                                String candidaturesLabel = String.join(", ", requeteTravail.getCandidatures());

                                if (titreProjet != null) {
                                    JOptionPane.showMessageDialog(
                                            frame,
                                            "Notification Résident #" + numberSelected +  "\nTitre de la notification: " + titreProjet + "\nDescription: " + message + 
                                                "\nTitre du travail: " + titreProjet + "\nDate de début: " + dateDebutLabel +
                                                "\nType de travaux: " + typeTravauxLabel + "\nDescription: " + descriptionLabel + "\nCandidatures: " + candidaturesLabel,
                                            "Item Selected",
                                            JOptionPane.INFORMATION_MESSAGE
                                    );
                                }
                            } else {
                                for (ProjetTravaux projet : MaVille.projets) {
                                    if (detailsDuTravail.getIdDocument().equals(projet.getId())) {
                                        projetTravaux = projet;
                                        estTrouve = true;
                                        break;
                                    }
                                }

                                if (estTrouve) {
                                    String typeTravauxLabel = projetTravaux.getTypeTravaux();
                                    ArrayList<String> quartiersAffectesLabel = projetTravaux.getQuartiersAffectes();
                                    ArrayList<String> rueAffecteesLabel = projetTravaux.getRuesAffectees();
                                    String dateDebutLabel = projetTravaux.getDateDebut();
                                    String dateFinLabel = projetTravaux.getDateFin();
                                    String horaireTravauxLabel = projetTravaux.getHoraireTravaux();

                                    if (titreProjet != null) {
                                        JOptionPane.showMessageDialog(
                                                frame,
                                                "Notification Intervenant #" + numberSelected +  "\nTitre de la notification: " + titreProjet + "\nDescription: " + message +
                                                    "\nTitre du travail: " + titreProjet +
                                                    "\nType de travaux: " + typeTravauxLabel + "\nQuartiers affectés: " + quartiersAffectesLabel + "\nRues affectées: " + rueAffecteesLabel +
                                                    "\nDate de début: " + dateDebutLabel + "\nDate de fin: " + dateFinLabel + "\nHoraire de travaux: " + horaireTravauxLabel,
                                                "Item Selected",
                                                JOptionPane.INFORMATION_MESSAGE
                                        );
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(
                                                frame,
                                                "Le projet n'a pas pu être trouvé",
                                                "Erreur",
                                                JOptionPane.ERROR_MESSAGE
                                        );
                                }


                            }
                        }
                    });

                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsProfile.get(0), componentsProfile.get(1), scrollPane, disconnection, goToMenu));

                    profilResidentPanel.showOnPanel(componentsResident);
                }
                default -> throw new AssertionError();
            }
            profilResidentPanel.revalidate();
            profilResidentPanel.repaint();
        });

        disconnection.addActionListener(e ->
                cardLayout.show(cardPanel, "Home")
        );
        goToMenu.addActionListener(e ->
                cardLayout.show(cardPanel, "MenuResident")
        );
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */

    private static void connectionPanel() {
        connectionPanel = new ImagePanel();
        connectionPanel.setLayout(new BoxLayout(connectionPanel, BoxLayout.Y_AXIS));
        JButton backToHomeFromConnection = new JButton("Retour au portail d'entrée");
        JLabel usernameLabel = new JLabel("Entrez le nom d'utilisateur:");
        JTextField usernameAnswer = createTextField();
        JLabel passwordLabel = new JLabel("Entrez le mot de passe:");
        JTextField passwordAnswer = createTextField();
        JButton connectionButton = new JButton("Connexion");

        ArrayList<JComponent> componentsHome = new ArrayList<>(
                Arrays.asList(new JLabel("Page de connexion"), backToHomeFromConnection, usernameLabel, usernameAnswer, passwordLabel, passwordAnswer, connectionButton));

        for (JComponent od:componentsHome) {
            od.setAlignmentX(Component.CENTER_ALIGNMENT);
            connectionPanel.add(od);
            connectionPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        }

        backToHomeFromConnection.addActionListener(e ->
                cardLayout.show(cardPanel, "Portail d'entrée")
        );
        connectionButton.addActionListener(e -> {
            String entryUserName = usernameAnswer.getText();
            String entryPassword = passwordAnswer.getText();
            if (entryUserName.isEmpty() || entryPassword.isEmpty()) {
                JOptionPane.showMessageDialog(connectionPanel,
                        "Tous les champs doivent être remplies",
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                String[] reponse = new String[2];
                try {
                    reponse = ActionProvider.connexion(entryUserName, entryPassword, MaVille.residents, MaVille.intervenants);
                } catch (IOException e1) {}

                switch (reponse[0]) {
                    case "Resident" -> {
                        idUtilisateur = reponse[1];
                        cardLayout.show(cardPanel, "MenuResident");
                    }
                    case "Intervenant" -> {
                        idUtilisateur = reponse[1];
                        cardLayout.show(cardPanel, "MenuIntervenant");
                    }
                    default -> JOptionPane.showMessageDialog(connectionPanel,
                                "Les entrées ne sont pas valides",
                                "Erreur",
                                JOptionPane.ERROR_MESSAGE);
                }

            }
        });
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */

    private static void inscriptionPanel() {
        inscriptionPanel = new ImagePanel();
        inscriptionPanel.setLayout(new BoxLayout(inscriptionPanel, BoxLayout.Y_AXIS));
        JButton backToHomeFromInscription = new JButton("Retour au portail d'entrée");
        JLabel nameLabel = new JLabel("Entrez votre nom:");
        JTextField nameAnswer = createTextField();
        JLabel dateOfBirthLabel = new JLabel("Entrez votre date de naissance:");
        JTextField dateOfBirthAnswer = createTextField();
        JLabel emailLabel = new JLabel("Entrez votre courriel:");
        JTextField emailAnswer = createTextField();
        JLabel passwordLabel = new JLabel("Entrez votre mot de passe:");
        JTextField passwordAnswer = createTextField();
        JLabel phoneNumberLabel = new JLabel("Entrez votre numéro de téléphone:");
        JTextField phoneNumberAnswer = createTextField();
        JLabel locationLabel = new JLabel("Entrez votre adresse postale:");
        JTextField locationAnswer = createTextField();
        JLabel typeBusinessLabel = new JLabel("Entrez votre type d'entreprise:");
        JTextField typeBusinessAnswer = createTextField();
        JLabel nbVerificationLabel = new JLabel("Entrez votre numéro de vérification:");
        JTextField nbVerificationAnswer = createTextField();
        JLabel preferencesLabel = new JLabel("Entrez vos préférences horaires (matin, midi, soir)");
        JTextField preferencesAnswer = createTextField();
        JButton submitButtonResident = new JButton("Soumettre");
        JButton submitButtonIntervenant = new JButton("Soumettre");


        String[] options = {"Intervenant", "Résident"};
        JComboBox<String> comboBox = new JComboBox<>(options);
        comboBox.setMaximumSize(new Dimension(max(300,frame.getWidth()/3), 30));

        ArrayList<JComponent> componentsInscription = new ArrayList<>(
                Arrays.asList(new JLabel("Page d'inscription"), comboBox));

        inscriptionPanel.showOnPanel(componentsInscription);


        comboBox.addActionListener(e -> {
            int r = comboBox.getSelectedIndex();
            inscriptionPanel.removeAll();
            switch (r) {
                case 0 -> {
                    ArrayList<JComponent> componentsIntervenant = new ArrayList<>(
                            Arrays.asList(componentsInscription.get(0), componentsInscription.get(1), backToHomeFromInscription,
                                    nameLabel, nameAnswer, emailLabel, emailAnswer, passwordLabel, passwordAnswer, typeBusinessLabel, typeBusinessAnswer,
                                    nbVerificationLabel, nbVerificationAnswer, submitButtonIntervenant));

                    inscriptionPanel.showOnPanel(componentsIntervenant);
                }
                case 1 -> {
                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsInscription.get(0), componentsInscription.get(1), backToHomeFromInscription,
                                    nameLabel, nameAnswer, dateOfBirthLabel, dateOfBirthAnswer, emailLabel, emailAnswer, passwordLabel, passwordAnswer,
                                    phoneNumberLabel, phoneNumberAnswer, locationLabel, locationAnswer, preferencesLabel, preferencesAnswer, submitButtonResident));

                    inscriptionPanel.showOnPanel(componentsResident);
                }
                default -> throw new AssertionError();
            }
            inscriptionPanel.revalidate();
            inscriptionPanel.repaint();
        });



        backToHomeFromInscription.addActionListener(e ->
                cardLayout.show(cardPanel, "Home")
        );
        submitButtonIntervenant.addActionListener(e -> {
            String entryName = nameAnswer.getText();
            String entryEmail = emailAnswer.getText();
            String entryPassword = passwordAnswer.getText();
            String entryType = typeBusinessAnswer.getText();
            String entryNumberVerification = nbVerificationAnswer.getText();
            if (entryName.isEmpty() || entryEmail.isEmpty() || entryPassword.isEmpty() ||
                    entryType.isEmpty() || entryNumberVerification.isEmpty()) {
                JOptionPane.showMessageDialog(connectionPanel,
                        "Toutes les champs doivent être remplies",
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                ActionProvider.inscrireIntervenant(entryName, entryEmail, entryPassword, entryType, entryNumberVerification, MaVille.intervenants);
                cardLayout.show(cardPanel, "Home");
            }
        });
        submitButtonResident.addActionListener(e -> {
            String entryName = nameAnswer.getText();
            String entryDateOfBirth = dateOfBirthAnswer.getText();
            String entryEmail = emailAnswer.getText();
            String entryPassword = passwordAnswer.getText();
            String entryPhoneNumber = phoneNumberAnswer.getText();
            String entryLocation = locationAnswer.getText();
            String entryPreferencesHoraires = preferencesAnswer.getText();
            if (entryName.isEmpty() || entryDateOfBirth.isEmpty() || entryEmail.isEmpty() || entryPassword.isEmpty() ||
                    entryPhoneNumber.isEmpty() || entryLocation.isEmpty()) {
                JOptionPane.showMessageDialog(connectionPanel,
                        "Toutes les champs doivent être remplies",
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                ActionProvider.inscrireResident(entryEmail, entryPassword, entryName, entryDateOfBirth, entryPhoneNumber, entryLocation, entryPreferencesHoraires, MaVille.residents);
                cardLayout.show(cardPanel, "Home");
            }
        });
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */

    private static void menuIntervenantPanel() {
        menuIntervenantPanel = new ImagePanel();
        menuIntervenantPanel.setLayout(new BoxLayout(menuIntervenantPanel, BoxLayout.Y_AXIS));
        JButton disconnection = new JButton("Déconnexion");
        JButton goToProfile = new JButton("Aller au profil");


        String[] optionsMenuIntervenant = {"Consulter la liste de requêtes de travail", "Soumettre un nouveau projet", "Mettre à jour un travail"};
        JComboBox<String> comboBox = new JComboBox<>(optionsMenuIntervenant);
        comboBox.setMaximumSize(new Dimension(max(300,frame.getWidth()/3), 30));

        ArrayList<JComponent> componentsMenu = new ArrayList<>(
                Arrays.asList(new JLabel("Menu Intervenant"), comboBox, disconnection, goToProfile));

        menuIntervenantPanel.showOnPanel(componentsMenu);


        JTextField titreProjetAnswer = createTextField();
        JTextField descriptionProjetAnswer = createTextField();
        JTextField typeTravauxAnswer = createTextField();
        JPanel checkboxPanel = new JPanel();
        checkboxPanel.setLayout(new BoxLayout(checkboxPanel, BoxLayout.Y_AXIS));
        ArrayList<JCheckBox> checkBoxs = new ArrayList<>();
        for (String quartier : app.quartiers) {
            JCheckBox checkBox = new JCheckBox(quartier);
            checkBoxs.add(checkBox);
            checkboxPanel.add(checkBox);
        }
        JScrollPane quartierAffectesAnswer = new JScrollPane(checkboxPanel);
        quartierAffectesAnswer.setMinimumSize(new Dimension(min(300, frame.getWidth() / 3), 75));
        quartierAffectesAnswer.setMaximumSize(new Dimension(max(300, frame.getWidth() / 3), 300));
        quartierAffectesAnswer.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        JTextField rueAffecteesAnswer = createTextField();
        JTextField dateDebutAnswer = createTextField();
        JTextField dateFinAnswer = createTextField();
        JTextField horaireTravauxAnswer = createTextField();


        comboBox.addActionListener(e -> {
            int r = comboBox.getSelectedIndex();
            menuIntervenantPanel.removeAll();
            switch (r) {
                case 0 -> { // Consulter la liste de requêtes de travail
                    // Afficher les requetes par API

                    ArrayList<RequeteTravail> requeteTravailsBD = MaVille.requetes;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    for (RequeteTravail item : requeteTravailsBD) {
                        listModel.addElement(item.getTitreTravail());
                    }

                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

                    // Lorsqu'un intervenant appuye sur une requête, il affiche un message de la requête et de son contenu

                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            RequeteTravail projetChoisi = requeteTravailsBD.get(numberSelected);
                            String typeTravauxLabel = projetChoisi.getTypeTravaux();
                            String dateDebutLabel = projetChoisi.getDateDebutEsperee();
                            String descriptionLabel = projetChoisi.getDescriptionDetaillee();
                            String candidaturesLabel = String.join(", ", projetChoisi.getCandidatures());
                            String[] options = {"Soumettre sa candidature", "Quitter"};

                            if (titreProjet != null) {
                                int choice = JOptionPane.showOptionDialog(
                                        frame,
                                        "Travail #" + numberSelected +  "\nTitre du travail: " + titreProjet + "\nDate de début: " + dateDebutLabel +
                                                "\nType de travaux: " + typeTravauxLabel + "\nDescription: " + descriptionLabel + "\nCandidatures: " + candidaturesLabel,                                        "Item Selected",
                                            JOptionPane.YES_NO_OPTION,
                                            JOptionPane.QUESTION_MESSAGE,
                                            null,
                                            options,
                                            options[0]
                                );

                                switch (choice) {
                                    case 0 -> {
                                        ActionProvider.addCandidature(projetChoisi.getID(), idUtilisateur);
                                    }
                                    case 1 -> {}
                                    default -> throw new AssertionError();
                                }
                            }
                        }
                    });

                    // Add the JList to a JScrollPane
                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsIntervenant = new ArrayList<>(
                            Arrays.asList(componentsMenu.get(0), componentsMenu.get(1), scrollPane, disconnection, goToProfile));

                    menuIntervenantPanel.showOnPanel(componentsIntervenant);
                }
                case 1 -> { // Soumettre un nouveau projet
                    // Vérifier à la fin si ce travail existe déjà, si oui, remplacer par les nouvelles informations misent
                    JLabel titreProjetLabel = new JLabel("Titre du projet:");
                    JLabel descriptionProjetLabel = new JLabel("Description du projet de travaux:");
                    JLabel typeTravauxLabel = new JLabel("Type de travaux:");
                    JLabel quartiersAffectesLabel = new JLabel("Quels sont les quartiers affectés?");
                    JLabel rueAffecteesLabel = new JLabel("Et dans quelles rues?");
                    JLabel dateDebutLabel = new JLabel("Entrez la date de début des travaux:");
                    JLabel dateFinLabel = new JLabel("Entrez la date de fin (approximative):");
                    JLabel horaireTravauxLabel = new JLabel("Quel est votre horaire de travaux?");
                    JButton submitForm = new JButton("Soumettre");

                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsMenu.get(0), componentsMenu.get(1),  titreProjetLabel, titreProjetAnswer,
                                    descriptionProjetLabel, descriptionProjetAnswer, typeTravauxLabel, typeTravauxAnswer, quartiersAffectesLabel,
                                    quartierAffectesAnswer, rueAffecteesLabel, rueAffecteesAnswer, dateDebutLabel, dateDebutAnswer, dateFinLabel,
                                    dateFinAnswer, horaireTravauxLabel, horaireTravauxAnswer, submitForm, disconnection, goToProfile));

                    menuIntervenantPanel.showOnPanel(componentsResident);

                    submitForm.addActionListener(f -> {
                        String entryTitreTravail = titreProjetAnswer.getText();
                        String entryDescription = descriptionProjetAnswer.getText();
                        String entryTypeTravaux = typeTravauxAnswer.getText();
                        ArrayList<String> selectedQuartiers = getSelectedCheckboxes(checkboxPanel);
                        String entryQuartiersAffectes = String.join(", ", selectedQuartiers);
                        String entryRuesAffectees = rueAffecteesAnswer.getText();
                        ArrayList<String> chosenStreets = new ArrayList<>(Arrays.asList(entryRuesAffectees.split(", ")));
                        String entryDateDebut = dateDebutAnswer.getText();
                        String entryDateFin = dateFinAnswer.getText();
                        String entryHoraireTravaux = horaireTravauxAnswer.getText();

                        try {
                            String idProjet = ActionProvider.soumettreProjet(idUtilisateur, entryTitreTravail, entryDescription, entryTypeTravaux, selectedQuartiers, chosenStreets, entryDateDebut, entryDateFin, entryHoraireTravaux);
                            ActionProvider.rajouterNotification(idUtilisateur, entryDateFin, entryDateFin, idUtilisateur);
                            Intervenant intervenant = null;
                            if (MaVille.intervenantsMap.containsKey(idUtilisateur)) {
                                intervenant = MaVille.intervenantsMap.get(idUtilisateur).entity;
                                System.out.println("Found Notif: " + intervenant);
                            }
                            ActionProvider.rajouterNotification(idUtilisateur, entryTitreTravail, intervenant.getNomComplet() + " vous envoie une nouveau projet", idProjet);
                        } catch (IOException e1) {}

                        JOptionPane.showMessageDialog(
                                frame,
                                "Votre formulaire dit:\nTitre du travail: " + entryTitreTravail + "\nDescription du travail: " + entryDescription +
                                        "\nType de travaux: " + entryTypeTravaux + "\nQuartiers affectés: " + entryQuartiersAffectes + "\nRues affectées: " +
                                        entryRuesAffectees + "\nDate de début: " + entryDateDebut + "\nDate de fin: " + entryDateFin + "\nHoraire de travaux: " + entryHoraireTravaux,
                                "Item Selected",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    });
                }
                case 2 -> { // Mettre à jour un travail
                    // Montrer les travaux en cours de l'intervenant par l'API
                    // Afficher les requetes par API

                    Map<String, ProjetTravaux> projetsTravauxBD = MaVille.projetsMap;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    Map<String, String> travaux_ID_Titre = new HashMap<>();
                    for (String item : projetsTravauxBD.keySet()) {
                        ProjetTravaux inst = projetsTravauxBD.get(item);
                        travaux_ID_Titre.put(inst.getTitre(), inst.getId());
                        listModel.addElement(inst.getTitre());
                    }

                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            String idProjet = travaux_ID_Titre.get(titreProjet);
                            ProjetTravaux projetChoisi = projetsTravauxBD.get(idProjet);
                            String typeTravauxLabel = projetChoisi.getTypeTravaux();
                            ArrayList<String> quartiersAffectesLabel = projetChoisi.getQuartiersAffectes();
                            ArrayList<String> rueAffecteesLabel = projetChoisi.getRuesAffectees();
                            String dateDebutLabel = projetChoisi.getDateDebut();
                            String dateFinLabel = projetChoisi.getDateFin();
                            String horaireTravauxLabel = projetChoisi.getHoraireTravaux();
                            String[] options = {"Yes", "No"};

                            if (titreProjet != null) {
                                int choice = JOptionPane.showOptionDialog(
                                        frame,
                                        "Travail #" + numberSelected +  "\nTitre du travail: " + titreProjet +
                                                "\nType de travaux: " + typeTravauxLabel + "\nQuartiers affectés: " + quartiersAffectesLabel + "\nRues affectées: " + rueAffecteesLabel +
                                                "\nDate de début: " + dateDebutLabel + "\nDate de fin: " + dateFinLabel + "\nHoraire de travaux: " + horaireTravauxLabel +
                                                "\n\nVoulez-vous modifier l'état de cette requête?",
                                        "Item Selected",
                                        JOptionPane.YES_NO_OPTION,
                                        JOptionPane.QUESTION_MESSAGE,
                                        null,
                                        options,
                                        options[0]
                                );

                                switch (choice) {
                                    case 0 -> {
                                        comboBox.setSelectedIndex(1);
                                        titreProjetAnswer.setText(titreProjet);
                                        typeTravauxAnswer.setText(typeTravauxLabel);
                                        //setSelectedCheckboxes(checkBoxs, quartiersAffectesLabel);
                                        String quarAffect = String.join(", ", quartiersAffectesLabel);
                                        for (JCheckBox checkbox: checkBoxs) {
                                            if (quarAffect.contains(checkbox.getText())) {
                                                checkbox.setSelected(true);
                                            }
                                        }
                                        checkboxPanel.revalidate();
                                        checkboxPanel.repaint();
                                        rueAffecteesAnswer.setText(String.join(", ", rueAffecteesLabel));
                                        dateDebutAnswer.setText(dateDebutLabel);
                                        dateFinAnswer.setText(dateFinLabel);
                                        horaireTravauxAnswer.setText(horaireTravauxLabel);
                                    }
                                    case 1 -> {}
                                    default -> throw new AssertionError();
                                }
                            }


                        }
                    });

                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsIntervenant = new ArrayList<>(
                            Arrays.asList(componentsMenu.get(0), componentsMenu.get(1), scrollPane, disconnection, goToProfile));

                    menuIntervenantPanel.showOnPanel(componentsIntervenant);
                }
                default -> throw new AssertionError();
            }
            menuIntervenantPanel.revalidate();
            menuIntervenantPanel.repaint();
        });



        disconnection.addActionListener(e ->
                cardLayout.show(cardPanel, "Home")
        );
        goToProfile.addActionListener(e ->
                cardLayout.show(cardPanel, "ProfilIntervenant")
        );
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */

    private static void menuResidentPanel() {
        menuResidentPanel = new ImagePanel();
        menuResidentPanel.setLayout(new BoxLayout(menuResidentPanel, BoxLayout.Y_AXIS));
        JButton disconnection = new JButton("Déconnexion");
        JButton goToProfile = new JButton("Page profil");


        String[] options = {"Rédiger une requête", "Rechercher les travaux", "Consulter les travaux", "Consulter les entraves"};
        JComboBox<String> comboBox = new JComboBox<>(options);
        comboBox.setMaximumSize(new Dimension(max(300,frame.getWidth()/3), 30));

        ArrayList<JComponent> componentsMenu = new ArrayList<>(
                Arrays.asList(new JLabel("This is the Resident Menu page"), comboBox, disconnection, goToProfile));

        menuResidentPanel.showOnPanel(componentsMenu);

        comboBox.addActionListener(e -> {
            int r = comboBox.getSelectedIndex();
            menuResidentPanel.removeAll();
            switch (r) {
                case 0 -> { // Rédiger une requête
                    JLabel titreTravailLabel = new JLabel("Titre du projet:");
                    JTextField titreTravailAnswer = createTextField();
                    JLabel descriptionLabel = new JLabel("Description du projet de travaux:");
                    JTextField descriptionAnswer = createTextField();
                    JLabel typeTravauxLabel = new JLabel("Type de travaux:");
                    JTextField typeTravauxAnswer = createTextField();
                    JLabel dateDebutLabel = new JLabel("Entrez la date de début des travaux:");
                    JTextField dateDebutAnswer = createTextField();
                    JButton submitForm = new JButton("Soumettre la requête");


                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsMenu.get(0), componentsMenu.get(1),  titreTravailLabel, titreTravailAnswer,
                                    descriptionLabel, descriptionAnswer, typeTravauxLabel, typeTravauxAnswer, dateDebutLabel, dateDebutAnswer, submitForm, disconnection, goToProfile));

                    menuResidentPanel.showOnPanel(componentsResident);

                    submitForm.addActionListener(f -> {
                        String entryTitreTravail = titreTravailAnswer.getText();
                        String entryDescription = descriptionAnswer.getText();
                        String entryTypeTravaux = typeTravauxAnswer.getText();
                        String entryDateDebut = dateDebutAnswer.getText();
                        
                        try {
                            String idRequete = ActionProvider.soumettreRequete(idUtilisateur, entryTitreTravail, entryDescription, entryTypeTravaux, entryDateDebut);
                            Resident resident = null;
                            if (MaVille.residentsMap.containsKey(idUtilisateur)) {
                                resident = MaVille.residentsMap.get(idUtilisateur).entity;
                                System.out.println("Found Notif: " + resident);
                            }
                            ActionProvider.rajouterNotification(idUtilisateur, entryTitreTravail, resident.getNomComplet() + " vous envoie une nouvelle requête", idRequete);
                        } catch (IOException e1) {}

                        JOptionPane.showMessageDialog(
                                frame,
                                "Votre formulaire dit:\nTitre du travail: " + entryTitreTravail + "\nDescription du travail: " + entryDescription +
                                        "\nType de travaux: " + entryTypeTravaux + "\nDate de début: " + entryDateDebut,
                                "Item Selected",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    });
                }
                case 1 -> { // Rechercher les travaux
                    // Afficher les requetes par API

                    JLabel titreProjetLabel = new JLabel("Titre du projet:");
                    JTextField titreProjetAnswer = createTextField();
                    JButton rechercher = new JButton("Rechercher");


                    Map<String, ProjetTravaux> projetsTravauxBD = MaVille.projetsMap;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    Map<String, String> travaux_ID_Titre = new HashMap<>();
                    for (String item : projetsTravauxBD.keySet()) {
                        ProjetTravaux inst = projetsTravauxBD.get(item);
                        travaux_ID_Titre.put(inst.getTitre(), inst.getId());
                        listModel.addElement(inst.getTitre());
                    }

                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

                    AtomicBoolean isSearchActive = new AtomicBoolean(false);


                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting() && !isSearchActive.get()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            if (titreProjet != null) {
                                String idProjet = travaux_ID_Titre.get(titreProjet);
                                ProjetTravaux projetChoisi = projetsTravauxBD.get(idProjet);
                    
                                if (projetChoisi != null) {
                                    String typeTravauxLabel = projetChoisi.getTypeTravaux();
                                    ArrayList<String> quartiersAffectesLabel = projetChoisi.getQuartiersAffectes();
                                    ArrayList<String> rueAffecteesLabel = projetChoisi.getRuesAffectees();
                                    String dateDebutLabel = projetChoisi.getDateDebut();
                                    String dateFinLabel = projetChoisi.getDateFin();
                                    String horaireTravauxLabel = projetChoisi.getHoraireTravaux();
                    
                                    JOptionPane.showMessageDialog(
                                        frame,
                                        "Travail #" + numberSelected + "\nTitre du travail: " + titreProjet +
                                        "\nType de travaux: " + typeTravauxLabel + "\nQuartiers affectés: " + quartiersAffectesLabel +
                                        "\nRues affectées: " + rueAffecteesLabel + "\nDate de début: " + dateDebutLabel +
                                        "\nDate de fin: " + dateFinLabel + "\nHoraire de travaux: " + horaireTravauxLabel +
                                        "\n\nVoulez-vous modifier l'état de cette requête?",
                                        "Item Selected",
                                        JOptionPane.INFORMATION_MESSAGE
                                    );
                                } else {
                                    System.err.println("No project found for title: " + titreProjet);
                                }
                            }
                        }
                    });

                    
                    // Add the JList to a JScrollPane
                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsMenu.get(0), componentsMenu.get(1), titreProjetLabel, titreProjetAnswer, rechercher, scrollPane, disconnection, goToProfile));

                    menuResidentPanel.showOnPanel(componentsResident);

                    rechercher.addActionListener(f -> {
                        String entryTitreProjet = titreProjetAnswer.getText().trim();
                    
                        if (entryTitreProjet.isEmpty()) {
                            return;
                        }
                    
                        isSearchActive.set(true);
                    
                        itemList.clearSelection();
                    
                        ArrayList<String> matchingItems = new ArrayList<>();
                    
                        for (int index = 0; index < listModel.getSize(); index++) {
                            String title = listModel.get(index);
                            if (title.contains(entryTitreProjet)) {
                                matchingItems.add(title);
                            }
                        }
                    
                        for (String item : matchingItems) {
                            listModel.removeElement(item);
                        }
                    
                        for (String item : matchingItems) {
                            listModel.add(0, item);
                        }
                    
                        isSearchActive.set(false);
                    });
                }
                case 2 -> { // Consulter les travaux
                    
                    Map<String, ProjetTravaux> projetsTravauxBD = MaVille.projetsMap;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    Map<String, String> travaux_ID_Titre = new HashMap<>();
                    for (String item : projetsTravauxBD.keySet()) {
                        ProjetTravaux inst = projetsTravauxBD.get(item);
                        travaux_ID_Titre.put(inst.getTitre(), inst.getId());
                        listModel.addElement(inst.getTitre());
                    }


                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            String idProjet = travaux_ID_Titre.get(titreProjet);
                            ProjetTravaux projetChoisi = projetsTravauxBD.get(idProjet);
                            String typeTravauxLabel = projetChoisi.getTypeTravaux();
                            ArrayList<String> quartiersAffectesLabel = projetChoisi.getQuartiersAffectes();
                            ArrayList<String> rueAffecteesLabel = projetChoisi.getRuesAffectees();
                            String dateDebutLabel = projetChoisi.getDateDebut();
                            String dateFinLabel = projetChoisi.getDateFin();
                            String horaireTravauxLabel = projetChoisi.getHoraireTravaux();

                            if (titreProjet != null) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Requête #" + numberSelected +  "\nTitre du travail: " + titreProjet +
                                                "\nType de travaux: " + typeTravauxLabel + "\nQuartiers affectés: " + quartiersAffectesLabel + "\nRues affectées: " + rueAffecteesLabel +
                                                "\nDate de début: " + dateDebutLabel + "\nDate de fin: " + dateFinLabel + "\nHoraire de travaux: " + horaireTravauxLabel,
                                        "Item Selected",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                        }
                    });

                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsMenu.get(0), componentsMenu.get(1), scrollPane, disconnection, goToProfile));

                    menuResidentPanel.showOnPanel(componentsResident);

                }
                case 3 -> { // Consulter les entraves
                    
                    ArrayList<Entrave> entravesBD = MaVille.entraves;

                    DefaultListModel<String> listModel = new DefaultListModel<>();
                    Map<String, String> entraves_ID_Titre = new HashMap<>();
                    for (int i = 0; i < entravesBD.size(); i++) {
                        Entrave inst = entravesBD.get(i);
                        entraves_ID_Titre.put(inst.getShortName(), inst.getIdRequest());
                        listModel.addElement(inst.getShortName());
                    }


                    JList<String> itemList = new JList<>(listModel);

                    itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


                    itemList.addListSelectionListener(f -> {
                        if (!f.getValueIsAdjusting()) {
                            int numberSelected = itemList.getSelectedIndex();
                            String titreProjet = itemList.getSelectedValue();
                            Entrave entraveChoisi = entravesBD.get(numberSelected);
                            String typeImpactLabel = entraveChoisi.getStreetImpactType();
                            String rueAffecteesLabel = entraveChoisi.getStreetId();

                            if (titreProjet != null) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Entrave #" + numberSelected +  "\nTitre de l'entrave: " + titreProjet + "\nNom de la rue: " + 
                                            rueAffecteesLabel + "\nType d'impact sur la rue: " + typeImpactLabel,
                                        "Entrave",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                        }
                    });

                    JScrollPane scrollPane = new JScrollPane(itemList);
                    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

                    ArrayList<JComponent> componentsResident = new ArrayList<>(
                            Arrays.asList(componentsMenu.get(0), componentsMenu.get(1), scrollPane, disconnection, goToProfile));

                    menuResidentPanel.showOnPanel(componentsResident);

                }
                default -> throw new AssertionError();
            }
            menuResidentPanel.revalidate();
            menuResidentPanel.repaint();
        });




        disconnection.addActionListener(e ->
                cardLayout.show(cardPanel, "Home")
        );
        goToProfile.addActionListener(e ->
                cardLayout.show(cardPanel, "ProfilResident")
        );
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */


    private static void showSplashScreen() {
        JWindow splashScreen = new JWindow();
        splashScreen.setSize(400, 300);
        splashScreen.setLayout(new BorderLayout());

        String imagePath = "src/main/java/org/example/img34.jpg";

        ImageIcon imageIcon = new ImageIcon(imagePath);
        Image image = imageIcon.getImage();
        int newWidth = imageIcon.getIconWidth();
        int newHeight = imageIcon.getIconHeight();
        Image resizedImage = image.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        ImageIcon splashImage = new ImageIcon(resizedImage);

        splashScreen.setSize(splashImage.getIconWidth(), splashImage.getIconHeight());

        JLabel imageLabel = new JLabel(splashImage);
        splashScreen.add(imageLabel, BorderLayout.CENTER);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screenSize.width - splashScreen.getSize().width) / 2;
        int y = (screenSize.height - splashScreen.getSize().height) / 2;
        splashScreen.setLocation(x, y);

        splashScreen.setVisible(true);

        Timer fadeTimer = new Timer();
        fadeTimer.schedule(new TimerTask() {
            float opacity = 1.0f;

            @Override
            public void run() {
                if (opacity > 0.0f) {
                    opacity -= 0.05f;
                    splashScreen.setOpacity(Math.max(opacity, 0.0f));
                } else {
                    splashScreen.dispose();
                    fadeTimer.cancel();
                    showMainApplication();
                }
            }
        }, 1000, 50);
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------------------- */

    public static JTextField createTextField() {
        JTextField textField = new JTextField(2);
        textField.setMaximumSize(new Dimension(max(300,frame.getWidth()/3), 30));
        textField.setBackground(Color.LIGHT_GRAY);
        textField.setForeground(Color.BLACK);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        return textField;
    }

    private static ArrayList<String> getSelectedCheckboxes(JPanel checkboxPanel) {
        ArrayList<String> selected = new ArrayList<>();

        for (Component comp : checkboxPanel.getComponents()) {
            if (comp instanceof JCheckBox checkBox) {
                if (checkBox.isSelected()) {
                    selected.add(checkBox.getText());
                }
            }
        }

        // Join selected items with ", " separator
        return selected;
    }
    
}

class ImagePanel extends JPanel {
    private Image backgroundImage;

    public ImagePanel() {
        this(new FlowLayout());
    }

    public ImagePanel(LayoutManager layout) {
        super(layout);
        String imagePath = "src/main/java/org/example/img34.jpg";
        backgroundImage = new ImageIcon(imagePath).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.2f));
            g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            g2d.dispose();
        }
    }

    public void showOnPanel(ArrayList<JComponent> components) {
        this.removeAll();
        for (JComponent component : components) {
            component.setAlignmentX(Component.CENTER_ALIGNMENT);
            this.add(component);
            this.add(Box.createVerticalStrut(10));
        }
        this.revalidate();
        this.repaint();
    }
}