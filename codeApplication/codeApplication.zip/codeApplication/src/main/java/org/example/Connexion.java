package org.example;

import java.io.IOException;
import java.util.ArrayList;

class Connexion {

    public static Intervenant intervenantConnected;
    public static Resident residentConnected;
    public static String[] connexion(String emailConnexion, String motDePasse, ArrayList<Resident> residents, ArrayList<Intervenant> intervenants) throws IOException {
        for (Resident resident : residents) {
            if (resident.getCourriel().equalsIgnoreCase(emailConnexion) && resident.getMotDePasse().equals(motDePasse)) {
                System.out.println("Connexion réussie en tant que Resident!");
                residentConnected = resident;
                return new String[]{"Resident", resident.getID()};
            }
        }

        for (Intervenant intervenant : intervenants) {
            if (intervenant.getCourriel().equalsIgnoreCase(emailConnexion) && intervenant.getMotDePasse().equals(motDePasse)) {
                System.out.println("Connexion réussie en tant qu'Intervenant!");
                intervenantConnected = intervenant;
                return new String[]{"Intervenant", intervenant.getIdentifiantVille()};
            }
        }

        return new String[]{"None",""};
    }
}
