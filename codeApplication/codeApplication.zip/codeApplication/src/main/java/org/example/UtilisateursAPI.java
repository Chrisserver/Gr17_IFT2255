package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.javalin.http.Context;

public class UtilisateursAPI {
    public static  String RESIDENTS_FILE_PATH = "src/main/resources/Residents.json";
    public static String INTERVENANTS_FILE_PATH = "src/main/resources/Intervenants.json";
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void getResidents(Context ctx) {
        List<Resident> residents = readFromFile(RESIDENTS_FILE_PATH, Resident.class);
        if (residents.isEmpty()) {
            ctx.status(404).json("Aucun résident trouvé");
        } else {
            ctx.status(200).json(residents);
        }
    }

    public static void addResident(Context ctx) {
        Resident resident = ctx.bodyAsClass(Resident.class);
        List<Resident> residents = readFromFile(RESIDENTS_FILE_PATH, Resident.class);
        resident.setID(UUID.randomUUID().toString()); // Génération d'un ID unique pour chaque résident
        residents.add(resident);
        writeToFile(RESIDENTS_FILE_PATH, residents);
        ctx.status(201).result("Résident ajouté avec succès !");
    }

    public static void getIntervenants(Context ctx) {
        List<Intervenant> intervenants = readFromFile(INTERVENANTS_FILE_PATH, Intervenant.class);
        if (intervenants.isEmpty()) {
            ctx.status(404).json("Aucun intervenant trouvé");
        } else {
            ctx.status(200).json(intervenants);
        }
    }

    public static void addIntervenant(Context ctx) {
        Intervenant intervenant = ctx.bodyAsClass(Intervenant.class);
        List<Intervenant> intervenants = readFromFile(INTERVENANTS_FILE_PATH, Intervenant.class);
        intervenants.add(intervenant);
        writeToFile(INTERVENANTS_FILE_PATH, intervenants);
        ctx.status(201).result("Intervenant ajouté avec succès !");
    }

    public static <T> List<T> readFromFile(String filePath, Class<T> entityType) {
        List<T> entities = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            StringBuilder jsonContent = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                jsonContent.append(line);
            }

            JSONArray jsonArray = new JSONArray(jsonContent.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (entityType == Resident.class) {
                    T entity = entityType.cast(new Resident(
                            jsonObject.getString("nomComplet"),
                            jsonObject.getString("courriel"),
                            jsonObject.getString("motDePasse"),
                            jsonObject.getString("dateDeNaissance"),
                            jsonObject.getString("telephone"),
                            jsonObject.getString("adresseResidentielle"),
                            jsonObject.getString("quartier"),
                            jsonObject.getString("preferencesHoraires"),
                            jsonObject.getString("ID"),
                            jsonArrayToArrayList(jsonObject.getJSONArray("notifications"))
                    ));
                    entities.add(entity);
                } else if (entityType == Intervenant.class) {
                    T entity = entityType.cast(new Intervenant(
                            jsonObject.getString("nomComplet"),
                            jsonObject.getString("courriel"),
                            jsonObject.getString("motDePasse"),
                            jsonObject.getString("type"),
                            jsonObject.getString("identifiantVille"),
                            ProjetAPI.jsonArrayToArrayList(jsonObject.getJSONArray("requetesCandidate"))
                    ));
                    entities.add(entity);
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier " + filePath + " : " + e.getMessage());
        }
        return entities;
    }

    public static <T> void writeToFile(String filePath, List<T> data) {
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            JSONArray jsonArray = new JSONArray();
            for (T entity : data) {
                if (entity instanceof Resident) {
                    Resident resident = (Resident) entity;
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("nomComplet", resident.getNomComplet());
                    jsonObject.put("courriel", resident.getCourriel());
                    jsonObject.put("motDePasse", resident.getMotDePasse());
                    jsonObject.put("dateDeNaissance", resident.getDateDeNaissance());
                    jsonObject.put("telephone", resident.getTelephone());
                    jsonObject.put("adresseResidentielle", resident.getAdresseResidentielle());
                    jsonObject.put("quartier",resident.getQuartier());
                    jsonObject.put("preferencesHoraires", resident.getPreferencesHoraires());
                    jsonObject.put("ID", resident.getID());
                    jsonObject.put("notifications",resident.getNotifications());
                    jsonArray.put(jsonObject);
                } else if (entity instanceof Intervenant) {
                    Intervenant intervenant = (Intervenant) entity;
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("nomComplet", intervenant.getNomComplet());
                    jsonObject.put("courriel", intervenant.getCourriel());
                    jsonObject.put("motDePasse", intervenant.getMotDePasse());
                    jsonObject.put("type", intervenant.getType());
                    jsonObject.put("identifiantVille", intervenant.getIdentifiantVille());
                    jsonObject.put("requetesCandidate",intervenant.getRequetesCandidate());
                    jsonArray.put(jsonObject);
                }
            }
            fileWriter.write(jsonArray.toString(4)); // Indentation de 4 espaces
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture du fichier " + filePath + " : " + e.getMessage());
        }
    }

    public static ArrayList<Notification> jsonArrayToArrayList(JSONArray jsonArray) {
        ArrayList<Notification> list = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            String id = jsonObject.getString("id");
            String idDocument = jsonObject.getString("idDocument");
            String idUtilisateur = jsonObject.getString("idUtilisateur");
            String titre = jsonObject.getString("titre");
            String message = jsonObject.getString("message");
            boolean vue = jsonObject.getBoolean("vue");

            Notification notification = new Notification(id, idDocument, idUtilisateur, message, titre);
            notification.setVue(vue); // Mettre à jour l'état de la notification
            list.add(notification);
        }
        return list;
    }

}
