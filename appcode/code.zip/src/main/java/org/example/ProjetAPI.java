package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import io.javalin.http.Context;

/**
 * Classe de recherche de projets par l'API à la base de données Projets.json
 */
public class ProjetAPI {
    private static final String FILE_PATH = "src/main/resources/Projets.json";

    /**
     * Permet d'aller lire et chercher les projets
     * @param ctx
     */
    public static void getProjets(Context ctx) {
        List<ProjetTravaux> projets = readFromFile(FILE_PATH, ProjetTravaux.class);
        if (projets.isEmpty()) {
            ctx.status(404).json("Aucun projet trouvé");
        } else {
            ctx.status(200).json(projets);
        }
    }

    /**
     * Permet de rajouter un nouveau projet
     * @param ctx
     */
    public static void addProjet(Context ctx) {
        ProjetTravaux projet = ctx.bodyAsClass(ProjetTravaux.class);
        List<ProjetTravaux> projets = readFromFile(FILE_PATH, ProjetTravaux.class);
        projets.add(projet);
        writeToFile(FILE_PATH, projets);
        ctx.status(201).result("Projet ajouté avec succès !");
    }

    /**
     * Méthode générique pour lire les données depuis un fichier JSON
     * @param <T>
     * @param filePath
     * @param entityType
     * @return
     */
    public static <T> List<T> readFromFile(String filePath, Class<T> entityType) {
        List<T> entities = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            StringBuilder jsonContent = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                jsonContent.append(line);
            }

            JSONArray jsonArray = new JSONArray(jsonContent.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                if (entityType == ProjetTravaux.class) {
                    T entity = entityType.cast(new ProjetTravaux(
                            jsonObject.getString("id"),
                            jsonObject.getString("titre"),
                            jsonObject.getString("description"),
                            jsonObject.getString("typeTravaux"),
                            jsonArrayToArrayList(jsonObject.getJSONArray("quartiersAffectes")),
                            jsonArrayToArrayList(jsonObject.getJSONArray("ruesAffectees")),
                            jsonObject.getString("dateDebut"),
                            jsonObject.getString("dateFin"),
                            jsonObject.getString("horaireTravaux"),
                            jsonObject.getString("statut")
                    ));
                    entities.add(entity);
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier " + filePath + " : " + e.getMessage());
        }
        return entities;
    }

    /**
     * Méthode utilitaire pour convertir JSONArray en ArrayList<String>
     * @param jsonArray
     * @return
     */
    public static ArrayList<String> jsonArrayToArrayList(JSONArray jsonArray) {
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            list.add(jsonArray.getString(i));
        }
        return list;
    }

    /**
     * Méthode générique pour écrire des données dans un fichier JSON
     * @param <T>
     * @param filePath
     * @param data
     */
    public static <T> void writeToFile(String filePath, List<T> data) {
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            JSONArray jsonArray = new JSONArray();
            for (T entity : data) {
                if (entity instanceof ProjetTravaux) {
                    ProjetTravaux projet = (ProjetTravaux) entity;
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("id", projet.getId());
                    jsonObject.put("titre", projet.getTitre());
                    jsonObject.put("description", projet.getDescription());
                    jsonObject.put("typeTravaux", projet.getTypeTravaux());
                    jsonObject.put("quartiersAffectes", new ArrayList<>(projet.getQuartiersAffectes()));
                    jsonObject.put("ruesAffectees", new ArrayList<>(projet.getRuesAffectees()));
                    jsonObject.put("dateDebut", projet.getDateDebut());
                    jsonObject.put("dateFin", projet.getDateFin());
                    jsonObject.put("horaireTravaux", projet.getHoraireTravaux());
                    jsonObject.put("statut", projet.getStatut());
                    jsonArray.put(jsonObject);
                }
            }
            fileWriter.write(jsonArray.toString(4)); // Indentation de 4 espaces
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture du fichier " + filePath + " : " + e.getMessage());
        }
    }
}
