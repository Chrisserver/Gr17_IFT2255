package org.example;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Classe qui permet d'aller charger les documents json en array ou en map
 */
public class ProjetEntravesService {
    private static ProjetEntravesService instance;
    private final ArrayList<ProjetTravaux> projets = new ArrayList<>();

    private ProjetEntravesService() {
    }

    public static ProjetEntravesService getInstance() {
        if (instance == null) {
            instance = new ProjetEntravesService();
        }
        return instance;
    }

    /**
     * Atteint les données du json et converti en ArrayList
     * @return
     * @throws IOException
     */
    public ArrayList<ProjetTravaux> chargerProjetsDepuisApi() throws IOException {
        projets.clear();

        // Charger depuis l'API locale
        ArrayList<ProjetTravaux> projetsLocaux = chargerProjetsDepuisApiLocale();
        if (projetsLocaux != null) {
            projets.addAll(projetsLocaux);
        }

        // Charger depuis l'API externe
        ArrayList<ProjetTravaux> projetsExternes = chargerProjetsDepuisApiExterne();
        if (projetsExternes != null) {
            projets.addAll(projetsExternes);
        }

        return projets;
    }

    /**
     * Permet d'avoir les données des fichiers préexistants
     * @return
     * @throws IOException
     */
    private ArrayList<ProjetTravaux> chargerProjetsDepuisApiLocale() throws IOException {
        String url = "http://localhost:7000/projets";
        HttpResponse<String> response = HttpClientMaVille.get(url);
        if (response != null && response.statusCode() == 200) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<ProjetTravaux>>() {}.getType();
            return gson.fromJson(response.body(), type);
        }
        System.out.println("Erreur de récupération des projets locaux.");
        return null;
    }

    /**
     * Permet d'atteindre les données provenenant de la ville
     * @return
     * @throws IOException
     */
    private ArrayList<ProjetTravaux> chargerProjetsDepuisApiExterne() throws IOException {
        String ressourceId = "cc41b532-f12d-40fb-9f55-eb58c9a2b12b";
        HttpClientTravauxAPI clientApi = new HttpClientTravauxAPI();
        ApiResponse response = clientApi.getData(ressourceId);
        if (response != null && response.getStatusCode() == 200) {
            ArrayList<ProjetTravaux> projetsExternes = new ArrayList<>();
            String responseBody = response.getBody();
            JSONObject jsonResponse = new JSONObject(responseBody);
            JSONArray records = jsonResponse.getJSONObject("result").getJSONArray("records");;

            for (int i = 0; i < records.length(); i++) {
                JSONObject projetJson = records.getJSONObject(i);
                String dateFinString = projetJson.optString("duration_end_date", "Non spécifié").substring(0, 10);
                LocalDate dateFin = LocalDate.parse(dateFinString);
                String Statut;
                if(dateFin.isBefore(LocalDate.now())){
                    Statut = "Prévu";
                }else{Statut="Fini";};
                String titre = projetJson.optString("reason_category", "Non spécifié") + " situé à " + projetJson.getString("boroughid");
                String typeTravaux = projetJson.optString("reason_category", "Non spécifié");
                if(!MaVille.TypeTravaux.contains(typeTravaux)){MaVille.TypeTravaux.add(typeTravaux);};
                String quartier = projetJson.optString("boroughid", "Non spécifié");
                String rue = projetJson.optString("streetid", "Non spécifié");
                String intervenant = projetJson.optString("organizationname", "Non spécifié");
                String statut = projetJson.optString("currentstatus", "Non spécifié");
                String categorie = projetJson.optString("submittercategory", "Non spécifié");
                String description = "Type de travaux : " + typeTravaux + ", Quartier : " + quartier + ", Rues affectées : " + rue + ", Intervenant : " + intervenant + ", Statut actuel : " + statut + ", Catégorie : " + categorie;
                ArrayList<String> quartiersAffectes = new ArrayList();
                quartiersAffectes.add(quartier);
                ArrayList<String> ruesAffectees = new ArrayList();
                ruesAffectees.add(rue);
                ProjetTravaux projet = new ProjetTravaux(projetJson.getString("id"), titre, description, typeTravaux, quartiersAffectes, ruesAffectees, projetJson.optString("duration_start_date", "Non spécifié").substring(0, 10), dateFinString, projetJson.optString("work_schedule", "Non spécifié"),Statut);
                projetsExternes.add(projet);
            }
            return projetsExternes;
        }
        System.out.println("Erreur de récupération des projets externes.");
        return null;
    }


    /**
     * Permet d'atteindre le fichier json et le transforme en ArrayList
     * @return
     */
    public ArrayList<Entrave> chargerEntravesDepuisApi() {
        ArrayList<Entrave> entraves = new ArrayList<>();
        String resourceId = "a2bc8014-488c-495d-941b-e7ae1999d1bd";
        HttpClientTravauxAPI clientApi = new HttpClientTravauxAPI();
        ApiResponse response = clientApi.getData(resourceId);
        if (response != null && response.getStatusCode() == 200) {
            String responseBody = response.getBody();
            JSONObject jsonResponse = new JSONObject(responseBody);
            JSONArray records = jsonResponse.getJSONObject("result").getJSONArray("records");

            for (int i = 0; i < records.length(); ++i) {
                JSONObject entraveJson = records.getJSONObject(i);
                Entrave entrave = new Entrave(
                        entraveJson.getString("id_request"),
                        entraveJson.getString("streetid"),
                        entraveJson.getString("shortname"),
                        entraveJson.getString("streetimpacttype")
                );
                entraves.add(entrave);
            }
        } else {
            System.out.println("Erreur lors de la récupération des entraves : " + response.getMessage());
        }
        return entraves;
    }

    /**
     * Afin de le mettre en Map
     * @return
     * @throws IOException
     */
    public Map<String, ProjetTravaux> chargerProjetsEnMap() throws IOException {
        ArrayList<ProjetTravaux> listeProjets = chargerProjetsDepuisApi();
        return convertirEnMap(listeProjets);
    }

    /**
     * Conversion en Map
     * @param liste
     * @return
     */
    private Map<String, ProjetTravaux> convertirEnMap(ArrayList<ProjetTravaux> liste) {
        Map<String, ProjetTravaux> map = new HashMap<>();
        for (ProjetTravaux projet : liste) {
            map.put(projet.getId(), projet);
        }
        return map;
    }
}
