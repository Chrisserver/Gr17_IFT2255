package org.example;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Classe accédant à la base de données requetes.json et en ressort les infos
 */
public class RequeteService {
    private static RequeteService instance;
    private final ArrayList<RequeteTravail> requetes = new ArrayList<>();

    private RequeteService() {
    }

    public static RequeteService getInstance() {
        if (instance == null) {
            instance = new RequeteService();
        }
        return instance;
    }

    /**
     * Charge les requetes par API de la base de données
     * @return
     * @throws IOException
     */
    public ArrayList<RequeteTravail> chargerRequetesDepuisApi() throws IOException {
        String url = "http://localhost:7000/requetes";
        HttpResponse<String> response = HttpClientMaVille.get(url);
        if (response != null && response.statusCode() == 200) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<RequeteTravail>>() {}.getType();
            return gson.fromJson(response.body(), type);
        }
        return new ArrayList<>();
    }

    /**
     * Charger les requêtes en Map
     * @return
     * @throws IOException
     */
    public Map<String, IndexedEntity<RequeteTravail>> chargerRequetesEnMap() throws IOException {
        ArrayList<RequeteTravail> listeRequetes = (ArrayList<RequeteTravail>)RequeteAPI.readFromFile("src/main/resources/requetes.json",RequeteTravail.class);
        return convertirEnMap(listeRequetes);
    }

    /**
     * Convertir les infos en Map
     * @param liste
     * @return
     */
    private Map<String, IndexedEntity<RequeteTravail>> convertirEnMap(ArrayList<RequeteTravail> liste) {
        Map<String, IndexedEntity<RequeteTravail>> map = new HashMap<>();
        for (int i = 0; i < liste.size(); i++) {
            RequeteTravail requete = liste.get(i);
            map.put(requete.getID(), new IndexedEntity<>(i, requete));
        }
        return map;
    }
    public static class IndexedEntity<T> {
        public int index;
        public T entity;

        public IndexedEntity(int index, T entity) {
            this.index = index;
            this.entity = entity;
        }
    }

}
