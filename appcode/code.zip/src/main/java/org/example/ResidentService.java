package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Classe permettant de loader les données de residents.json
 */
class ResidentService {
    private static ResidentService instance;
    private final ArrayList<Resident> residents = new ArrayList<>();

    private ResidentService() {
    }

    public static ResidentService getInstance() {
        if (instance == null) {
            instance = new ResidentService();
        }
        return instance;
    }

    /**
     * Permet de charger les données dans un ArrayList
     * @return
     * @throws IOException
     */
    public ArrayList<Resident> chargerResidentsDepuisApi() throws IOException {
        residents.clear();
        String url = "http://localhost:7000/residents";
        HttpResponse<String> response = HttpClientMaVille.get(url);
        if (response != null && response.statusCode() == 200) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<Resident>>() {}.getType();
            ArrayList<Resident> newResidents = gson.fromJson(response.body(), type);
            residents.addAll(newResidents);
            return residents;
        }
        return residents;
    }

    /**
     * Permet de charger les données dans une Map
     * @return
     * @throws IOException
     */
    public Map<String, IndexedEntity<Resident>> chargerResidentsEnMap() throws IOException {
        ArrayList<Resident> listeResidents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json",Resident.class);
        return convertirEnMap(listeResidents);
    }

    /**
     * Conversion pour un Map
     * @param liste
     * @return
     */
    private Map<String, IndexedEntity<Resident>> convertirEnMap(ArrayList<Resident> liste) {
        Map<String, IndexedEntity<Resident>> map = new HashMap<>();
        for (int i = 0; i < liste.size(); i++) {
            Resident resident = liste.get(i);
            map.put(resident.getID(), new IndexedEntity<>(i, resident));
        }
        return map;
    }

    /**
     * Permet de notifier les résidents d'un même quartier
     * @param quartiers
     * @param message
     */
    public void notifierResidentsParQuartier( ArrayList<String> quartiers , String message) {
        ArrayList<Resident> residents = MaVille.residents;

        for (Resident resident : residents) {
            // Vérifiez si l'adresse résidentielle correspond à l'un des quartiers
            for (String quartier : quartiers) {
                if (resident.getQuartier().equalsIgnoreCase(quartier)) {
                    Notification notification = new Notification(UUID.randomUUID().toString(), "", "", UUID.randomUUID().toString(), message);
                    resident.getNotifications().add(notification);
                    break;
                }
            }
        }

        // Sauvegarde dans le fichier JSON après mise à jour
        UtilisateursAPI.writeToFile("src/main/resources/Residents.json", residents);
        MaVille.residents = (ArrayList<Resident>) UtilisateursAPI.readFromFile("src/main/resources/Residents.json", Resident.class);
    }



    /**
     * Permet d'avoir le quartier selon le code postal
     * @param codePostal
     * @return
     */
    public static String getQuartierParCodePostal(String codePostal) {
       String FILE_PATH = "src/main/resources/codesPostaux.csv";
         Map<String, String> codesPostauxMap = new HashMap<>();
        // Charger les codes postaux uniquement si la map est vide
        if (codesPostauxMap.isEmpty()) {
            try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(","); // Supposons que le fichier est délimité par des virgules
                    if (parts.length == 2) {
                        codesPostauxMap.put(parts[0].trim(), parts[1].trim());
                    }
                }
            } catch (IOException e) {
                System.out.println("Erreur lors du chargement des codes postaux : " + e.getMessage());
            }
        }

        // Retourner le quartier correspondant ou "Quartier inconnu" par défaut
        return codesPostauxMap.getOrDefault(codePostal, "Quartier inconnu");
    }


    public static class IndexedEntity<T> {
        public int index;
        public T entity;

        public IndexedEntity(int index, T entity) {
            this.index = index;
            this.entity = entity;
        }
    }
}
