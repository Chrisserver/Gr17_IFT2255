package org.example;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Classe permettant d'écrire et de lire dans le fichier json
 */
public class NotificationService {

    private static NotificationService instance;
    private final ArrayList<Notification> notifications = new ArrayList<>();

    private NotificationService() {
    }

    public static NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    /**
     * Charge les notifications depuis le fichier Notifications. json
     * @return
     * @throws IOException
     */
    public ArrayList<Notification> chargerNotificationsDepuisApi() throws IOException {
        String url = "http://localhost:7000/Notifications";
        HttpResponse<String> response = HttpClientMaVille.get(url);
        if (response != null && response.statusCode() == 200) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<Notification>>() {}.getType();
            return gson.fromJson(response.body(), type);
        }
        return new ArrayList<>();
    }

    /**
     * Charge les notifications en Map
     * @return
     * @throws IOException
     */
    public Map<String, IndexedEntity<Notification>> chargerNotificationsEnMap() throws IOException {
        ArrayList<Notification> listeNotifications = (ArrayList<Notification>) NotificationAPI.readFromFile("src/main/resources/Notifications.json",Notification.class);
        return convertirEnMap(listeNotifications);
    }

    /**
     * Transformation en Map
     * @param liste
     * @return
     */
    private Map<String, IndexedEntity<Notification>> convertirEnMap(ArrayList<Notification> liste) {
        Map<String, IndexedEntity<Notification>> map = new HashMap<>();
        for (int i = 0; i < liste.size(); i++) {
            Notification notif = liste.get(i);
            map.put(notif.getId(), new IndexedEntity<>(i, notif));
        }
        return map;
    }
    
    public static class IndexedEntity<T> {
        public int index;
        public T entity;

        public IndexedEntity(int index, T entity) {
            this.index = index;
            this.entity = entity;
        }
    }
    
}
