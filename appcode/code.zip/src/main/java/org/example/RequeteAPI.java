package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.javalin.http.Context;

/**
 * Classe permettant de modifier le fichier requetes.json
 */
public class RequeteAPI {
    private static final String FILE_PATH = "src/main/resources/requetes.json";
    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * Recherche les requetes
     * @param ctx
     */
    public static void getRequetes(Context ctx) {
        List<RequeteTravail> requetes = readFromFile(FILE_PATH, RequeteTravail.class);
        if (requetes.isEmpty()) {
            ctx.status(404).json("Aucune requête trouvée");
        } else {
            ctx.status(200).json(requetes);
        }
    }

    /**
     * Ajoute une nouvelle requete
     * @param ctx
     */
    public static void addRequete(Context ctx) {
        RequeteTravail requete = ctx.bodyAsClass(RequeteTravail.class);
        List<RequeteTravail> requetes = readFromFile(FILE_PATH, RequeteTravail.class);
        requetes.add(requete);
        writeToFile(FILE_PATH, requetes);
        ctx.status(201).result("Requête ajoutée avec succès !");
    }

    /**
     * Lit dans le fichier et renvoie le contenu en liste
     * @param <T>
     * @param filePath
     * @param entityType
     * @return
     */
    public static <T> List<T> readFromFile(String filePath, Class<T> entityType) {
        List<T> entities = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            StringBuilder jsonContent = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                jsonContent.append(line);
            }

            JSONArray jsonArray = new JSONArray(jsonContent.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (entityType == RequeteTravail.class) {
                    T entity = entityType.cast(new RequeteTravail(
                            jsonObject.getString("titreTravail"),
                            jsonObject.getString("descriptionDetaillee"),
                            jsonObject.getString("typeTravaux"),
                            jsonObject.getString("dateDebutEsperee"),
                            ProjetAPI.jsonArrayToArrayList(jsonObject.getJSONArray("candidatures")),
                            jsonObject.getString("ID"),
                            jsonObject.getString("residentID")
                    ));
                    entities.add(entity);
                }
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la lecture du fichier " + filePath + " : " + e.getMessage());
        }
        return entities;
    }

    /**
     * Écrit dans le fichier requetes.json
     * @param <T>
     * @param filePath
     * @param data
     */
    public static <T> void writeToFile(String filePath, List<T> data) {
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            JSONArray jsonArray = new JSONArray();
            for (T entity : data) {
                if (entity instanceof RequeteTravail) {
                    RequeteTravail requete = (RequeteTravail) entity;
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("titreTravail", requete.getTitreTravail());
                    jsonObject.put("descriptionDetaillee", requete.getDescriptionDetaillee());
                    jsonObject.put("typeTravaux", requete.getTypeTravaux());
                    jsonObject.put("dateDebutEsperee", requete.getDateDebutEsperee());
                    jsonObject.put("candidatures", new ArrayList<>(requete.getCandidatures()));
                    jsonObject.put("ID", requete.getID());
                    jsonObject.put("residentID", requete.getResidentID());
                    jsonArray.put(jsonObject);
                }
            }
            fileWriter.write(jsonArray.toString(4)); // Indentation de 4 espaces
        } catch (IOException e) {
            System.out.println("Erreur lors de l'écriture du fichier " + filePath + " : " + e.getMessage());
        }
    }
}
