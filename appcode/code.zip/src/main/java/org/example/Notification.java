package org.example;

/**
 * Classe d'instance de notification
 */
public class Notification {
    private final String id;
    private final String idUtilisateur;
    private final String titre;
    private final String message;
    private final String idDocument;
    private boolean vue;

    public Notification(String id, String idDocument, String idUtilisateur, String message, String titre) {
        this.id = id;
        this.idDocument = idDocument;
        this.idUtilisateur = idUtilisateur;
        this.message = message;
        this.titre = titre;
        this.vue = false;
    }

    

    public String getId() {
        return id;
    }

    public String getMessage() {
        return message;
    }

    public boolean getVue() {
        return vue;
    }

    public void setVue(boolean vue) {
        this.vue = vue;
    }

    public String getIdUtilisateur() {
        return idUtilisateur;
    }

    public String getTitre() {
        return titre;
    }

    public String getIdDocument() {
        return idDocument;
    }
}
